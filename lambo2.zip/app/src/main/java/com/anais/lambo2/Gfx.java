package com.anais.lambo2;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;

import java.util.HashMap;
import java.util.Locale;

/** Pixel art : tout est dessiné dans un petit framebuffer (H = 180 px), agrandi sans lissage. */
final class Gfx {
    static final int[] BGID = {R.drawable.bg_0, R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3,
            R.drawable.bg_4, R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7};
    static final int L = 0, C = 1, RT = 2;
    static final int[] BAYER = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

    final Resources res;
    Bitmap fb;
    Canvas c;
    int W, H;
    final Bitmap spr, fnt, map;
    final Bitmap[] bg = new Bitmap[8];
    final Paint p = new Paint(), pS = new Paint(), pT = new Paint();
    final Paint[] dith = new Paint[3];
    final Rect rs = new Rect(), rd = new Rect();
    final HashMap<Integer, PorterDuffColorFilter> cf = new HashMap<Integer, PorterDuffColorFilter>();
    final Path path = new Path();
    Bitmap titleB, betB, podB;

    Bitmap title() {
        if (titleB == null) titleB = load(R.drawable.title);
        return titleB;
    }

    Bitmap bet() {
        if (betB == null) betB = load(R.drawable.bet);
        return betB;
    }

    Bitmap podium() {
        if (podB == null) podB = load(R.drawable.podium);
        return podB;
    }

    void tri(float x1, float y1, float x2, float y2, float x3, float y3) {
        path.reset();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        c.drawPath(path, p);
    }

    Gfx(Resources r) {
        res = r;
        pS.setFilterBitmap(false);
        pS.setDither(false);
        pT.setFilterBitmap(false);
        spr = load(R.drawable.spr);
        fnt = load(R.drawable.font);
        map = load(R.drawable.map);
        for (int k = 0; k < 3; k++) {
            Bitmap b = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888);
            int lvl = (k + 1) * 4;
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 4; x++) b.setPixel(x, y, BAYER[y * 4 + x] < lvl ? 0xFF000000 : 0);
            }
            Paint q = new Paint();
            q.setShader(new BitmapShader(b, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            dith[k] = q;
        }
    }

    Bitmap load(int id) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeResource(res, id, o);
    }

    Bitmap bgSheet(int i) {
        if (bg[i] == null) bg[i] = load(BGID[i]);
        return bg[i];
    }

    void size(int w, int h) {
        W = w;
        H = h;
        fb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        c = new Canvas(fb);
    }

    // ---------------------------------------------------------------- primitives
    void rect(float x, float y, float w, float h, int col) {
        p.setColor(col);
        c.drawRect(x, y, x + w, y + h, p);
    }

    /** assombrit l'écran avec une trame (0 = 25 %, 1 = 50 %, 2 = 75 %) */
    void dim(int lvl, int x, int y, int w, int h) {
        c.drawRect(x, y, x + w, y + h, dith[lvl]);
    }

    void blit(Bitmap b, int sx, int sy, int sw, int sh, int dx, int dy, int dw, int dh) {
        rs.set(sx, sy, sx + sw, sy + sh);
        rd.set(dx, dy, dx + dw, dy + dh);
        c.drawBitmap(b, rs, rd, pS);
    }

    void sprite(int[] r, float x, float y, float w, float h) {
        int dx = Math.round(x), dy = Math.round(y);
        blit(spr, r[0], r[1], r[2], r[3], dx, dy, Math.max(1, Math.round(x + w) - dx), Math.max(1, Math.round(y + h) - dy));
    }

    /** sprite centré en cx, posé sur by, de largeur w (proportions conservées) */
    void spriteB(int[] r, float cx, float by, float w) {
        float h = w * r[3] / r[2];
        sprite(r, cx - w / 2f, by - h, w, h);
    }

    void spriteBFlip(int[] r, float cx, float by, float w) {
        c.save();
        c.scale(-1f, 1f, cx, 0f);
        spriteB(r, cx, by, w);
        c.restore();
    }

    void sprite1(int[] r, int x, int y, int k) {
        blit(spr, r[0], r[1], r[2], r[3], x, y, r[2] * k, r[3] * k);
    }

    /** panneau 9 tranches (sprite 24 x 24, coins de 5 px) */
    void nine(int[] r, int x, int y, int w, int h) {
        if (w < 11) w = 11;
        if (h < 11) h = 11;
        int s = 5, sx = r[0], sy = r[1], mw = r[2] - 2 * s, mh = r[3] - 2 * s;
        blit(spr, sx, sy, s, s, x, y, s, s);
        blit(spr, sx + s + mw, sy, s, s, x + w - s, y, s, s);
        blit(spr, sx, sy + s + mh, s, s, x, y + h - s, s, s);
        blit(spr, sx + s + mw, sy + s + mh, s, s, x + w - s, y + h - s, s, s);
        blit(spr, sx + s, sy, mw, s, x + s, y, w - 2 * s, s);
        blit(spr, sx + s, sy + s + mh, mw, s, x + s, y + h - s, w - 2 * s, s);
        blit(spr, sx, sy + s, s, mh, x, y + s, s, h - 2 * s);
        blit(spr, sx + s + mw, sy + s, s, mh, x + w - s, y + s, s, h - 2 * s);
        blit(spr, sx + s, sy + s, mw, mh, x + s, y + s, w - 2 * s, h - 2 * s);
    }

    void panel(int x, int y, int w, int h) {
        nine(Atlas.BTN[0], x, y, w, h);
    }

    // ---------------------------------------------------------------- texte bitmap
    PorterDuffColorFilter filter(int col) {
        PorterDuffColorFilter f = cf.get(col);
        if (f == null) {
            f = new PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN);
            cf.put(col, f);
        }
        return f;
    }

    int tw(String s, int k) {
        return s.length() * 6 * k - k;
    }

    void raw(String s, int x, int y, int k, int col) {
        pT.setColorFilter(filter(col));
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == ' ') continue;
            int idx = Atlas.FONT.indexOf(ch);
            if (idx < 0) idx = Atlas.FONT.indexOf('?');
            rs.set(idx * 6, 0, idx * 6 + 6, 10);
            int dx = x + i * 6 * k;
            rd.set(dx, y - 2 * k, dx + 6 * k, y + 8 * k);
            c.drawBitmap(fnt, rs, rd, pT);
        }
    }

    /** y = haut des majuscules ; al : 0 gauche, 1 centre, 2 droite */
    void text(String s, int x, int y, int k, int col, int al, boolean sh) {
        s = s.toUpperCase(Locale.FRANCE);
        int w = tw(s, k);
        if (al == C) x -= w / 2;
        else if (al == RT) x -= w;
        if (sh) raw(s, x + k, y + k, k, ((col >>> 24) << 24) | (((col & 0xFCFCFC) >> 2) & 0x00FFFFFF));
        raw(s, x, y, k, col);
    }

    void text(String s, int x, int y, int k, int col, int al) {
        text(s, x, y, k, col, al, true);
    }

    // ---------------------------------------------------------------- calques de fond (160 px de large mini)
    /** dessine une bande de la feuille (512 de large) avec défilement horizontal bouclé */
    void band(Bitmap b, int srcY, int srcH, float off, int dy) {
        int o = (int) (((off % 512f) + 512f) % 512f);
        blit(b, 0, srcY, 512, srcH, -o, dy, 512, srcH);
        blit(b, 0, srcY, 512, srcH, 512 - o, dy, 512, srcH);
    }
}
