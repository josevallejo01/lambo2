package com.anais.lambo2;

/** Généré par gen_all.py : positions des sprites dans spr.png, police et carte. */
final class Atlas {
    static final int[][] PL = {{0,0,56,30},{57,0,56,30},{114,0,56,30},{171,0,56,30},{228,0,56,30},{285,0,56,30},{342,0,56,30},{399,0,56,30},{456,0,56,30},{0,31,56,30},{57,31,56,30},{114,31,56,30},{171,31,56,30},{228,31,56,30},{285,31,56,30},{342,31,56,30},{399,31,56,30},{456,31,56,30},{0,62,56,30},{57,62,56,30},{114,62,56,30},{171,62,56,30},{228,62,56,30},{285,62,56,30}};
    static final int[][] SPORT = {{342,62,56,30},{399,62,56,30},{456,62,56,30},{0,93,56,30},{57,93,56,30},{114,93,56,30}};
    static final int[][] SEDAN = {{171,93,56,30},{228,93,56,30},{285,93,56,30},{342,93,56,30},{399,93,56,30},{456,93,56,30}};
    static final int[][] TRUCK = {{0,124,56,48},{57,124,56,48}};
    static final int[][] POLICE = {{114,124,56,30},{171,124,56,30}};
    static final int[] SAGUARO = {228,124,26,52};
    static final int[] PALM = {255,124,48,72};
    static final int[] PINE = {304,124,40,72};
    static final int[] OAK = {345,124,52,60};
    static final int[] ROCK = {398,124,48,28};
    static final int[] BUSH = {447,124,28,14};
    static final int[] JOSHUA = {476,124,30,40};
    static final int[][] BOARD = {{0,197,60,60},{61,197,60,60},{122,197,60,60}};
    static final int[][] LAMP = {{183,197,28,60},{212,197,28,60}};
    static final int[][][] BUILD = {{{241,197,40,66},{282,197,44,84},{327,197,48,102}},{{376,197,40,66},{417,197,44,84},{462,197,48,102}},{{0,300,40,66},{41,300,44,84},{86,300,48,102}},{{135,300,40,66},{176,300,44,84},{221,300,48,102}},{{270,300,40,66},{311,300,44,84},{356,300,48,102}},{{405,300,40,66},{446,300,44,84},{0,403,48,102}},{{49,403,40,66},{90,403,44,84},{135,403,48,102}},{{184,403,40,66},{225,403,44,84},{270,403,48,116}}};
    static final int[][] PICK_HEART = {{319,403,24,22},{344,403,24,22}};
    static final int[] PICK_BOLT = {369,403,24,24};
    static final int[][] PICK_COIN = {{394,403,22,22},{417,403,22,22},{440,403,22,22},{463,403,22,22}};
    static final int[] ICON_HEART = {486,403,12,11};
    static final int[] ICON_BOLT = {499,403,10,14};
    static final int[] ICON_COIN = {0,520,12,12};
    static final int[] ICON_LOCK = {13,520,10,12};
    static final int[] ICON_STAR = {24,520,11,11};
    static final int[] ICON_STAR0 = {36,520,11,11};
    static final int[] ICON_SHIELD = {48,520,11,13};
    static final int[] ICON_ENGINE = {60,520,14,12};
    static final int[] ICON_TIRE = {75,520,12,12};
    static final int[] ICON_BRAKE = {88,520,12,12};
    static final int[] ICON_FLAME = {101,520,10,13};
    static final int[] ICON_CHECK = {112,520,11,9};
    static final int[] ICON_FLAG = {124,520,12,12};
    static final int[] ICON_AL = {137,520,8,12};
    static final int[] ICON_AR = {146,520,8,12};
    static final int[][] PIN = {{155,520,14,19},{170,520,14,19},{185,520,14,19}};
    static final int[][] BTN = {{200,520,24,24},{225,520,24,24},{250,520,24,24},{275,520,24,24}};
    static final int[] LOGO = {300,520,118,30};
    static final float[][] MAP_PTS = {{140.5f,108.0f},{211.4f,139.5f},{299.3f,159.4f},{88.9f,100.9f},{174.3f,79.1f},{262.4f,65.2f},{123.0f,101.8f},{331.8f,72.6f}};
    static final String FONT = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:;!?-+/%$×'()<>=*·#ÉÈÊÀÂÇÔÛÎ";
    // bg_N.png : ciel 0-96, nuages 96-136, loin 136-200, près 200-264, bande 264-292, brume 292-316
}
