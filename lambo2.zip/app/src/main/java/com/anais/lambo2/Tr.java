package com.anais.lambo2;

/** Données des pistes (USA). Tout est généré par code : aucun asset. */
final class Tr {
    final String name, state, boss;
    final int skyT, skyB, g1, g2, rd1, rd2, rm1, rm2, bg, bgFar, bgNear, sun;
    final int[] objs, bcols;
    final boolean night;
    final int len, laps, traffic, seed;
    final float hill, curve, rp;

    Tr(String name, String state, String boss, int skyT, int skyB, int g1, int g2,
       int rd1, int rd2, int rm1, int rm2, int bg, int bgFar, int bgNear,
       int[] objs, int sun, boolean night, int len, int laps, float hill, float curve,
       int traffic, float rp, int seed, int[] bcols) {
        this.name = name; this.state = state; this.boss = boss;
        this.skyT = skyT; this.skyB = skyB; this.g1 = g1; this.g2 = g2;
        this.rd1 = rd1; this.rd2 = rd2; this.rm1 = rm1; this.rm2 = rm2;
        this.bg = bg; this.bgFar = bgFar; this.bgNear = bgNear;
        this.objs = objs; this.sun = sun; this.night = night;
        this.len = len; this.laps = laps; this.hill = hill; this.curve = curve;
        this.traffic = traffic; this.rp = rp; this.seed = seed; this.bcols = bcols;
    }

    // objs : 0 cactus 1 palmier 2 sapin 3 rocher 4 panneau 5 immeuble 6 lampadaire 7 arbre
    // bg   : 0 mesas 1 ville basse 2 ville néon 3 collines 4 montagnes enneigées 5 gratte-ciel
    static final Tr[] ALL = {
        new Tr("Route 66", "Arizona", "Dusty Jack",
            0xFF3F83D6, 0xFFF5D6A0, 0xFFDDA766, 0xFFD29B5B, 0xFF6E6A66, 0xFF77736F,
            0xFFC0392B, 0xFFF2F2F2, 0, 0xFFD39B6E, 0xFFAE6A41,
            new int[]{0, 3, 4, 0, 3}, 0xFFFFF2B0, false, 2200, 2, 0.8f, 0.9f, 14, 0.86f, 11,
            new int[]{0xFFC9A27A, 0xFFB5835A}),
        new Tr("Hill Country", "Texas", "Big Tex",
            0xFF3B8ED8, 0xFFFFE0A3, 0xFFA3BE55, 0xFF97B34A, 0xFF5C5852, 0xFF65615B,
            0xFFB03A2E, 0xFFF2F2F2, 3, 0xFFC4B377, 0xFFA6955C,
            new int[]{7, 4, 3, 7, 7}, 0xFFFFF6C8, false, 2400, 2, 1.0f, 1.1f, 16, 0.88f, 22,
            new int[]{0xFFB0A080}),
        new Tr("Ocean Drive", "Floride", "Miami Mike",
            0xFFFF6F61, 0xFFFFC38B, 0xFF39B56E, 0xFF30A363, 0xFF55555F, 0xFF5E5E69,
            0xFF1ABC9C, 0xFFF8F8F8, 1, 0xFFE58AA8, 0xFFC25C86,
            new int[]{1, 6, 5, 1, 1}, 0xFFFFE9A8, false, 2400, 2, 0.3f, 1.0f, 18, 0.90f, 33,
            new int[]{0xFFF7A8C4, 0xFF7FE0D0, 0xFFFFE08A}),
        new Tr("Pacific Coast Hwy", "Californie", "Cali Kate",
            0xFF2E86DE, 0xFFBFE9FF, 0xFF7DAA4F, 0xFF6F9945, 0xFF50505A, 0xFF595963,
            0xFFE67E22, 0xFFF2F2F2, 3, 0xFF86B7DA, 0xFF5E94B8,
            new int[]{1, 3, 4, 1, 3}, 0xFFFFF4C0, false, 2800, 2, 1.5f, 1.4f, 16, 0.92f, 44,
            new int[]{0xFFDDDDDD}),
        new Tr("Rocky Mountains", "Colorado", "Rocky",
            0xFF5DA9E9, 0xFFDDF1FF, 0xFF2F7D3B, 0xFF2A7035, 0xFF4A4A4F, 0xFF535358,
            0xFFD35400, 0xFFF2F2F2, 4, 0xFF95AEC8, 0xFF627F9E,
            new int[]{2, 2, 3, 2, 4}, 0, false, 3000, 2, 2.0f, 1.3f, 14, 0.94f, 55,
            new int[]{0xFF8D6E63}),
        new Tr("Windy City Loop", "Illinois", "Windy Joe",
            0xFF1F4E79, 0xFF9CC9E8, 0xFF4C9A5E, 0xFF438F55, 0xFF454549, 0xFF4E4E52,
            0xFF2980B9, 0xFFF2F2F2, 5, 0xFF6F8FB0, 0xFF4B6585,
            new int[]{5, 6, 7, 5, 6}, 0, false, 2600, 2, 0.2f, 1.2f, 20, 0.95f, 66,
            new int[]{0xFF7D93AD, 0xFF5D7390, 0xFF9DB0C4}),
        new Tr("Las Vegas Strip", "Nevada", "Vegas Vince",
            0xFF050518, 0xFF3B1A5A, 0xFF1D1D2C, 0xFF171726, 0xFF2B2B35, 0xFF32323D,
            0xFFFF2E93, 0xFF20E0FF, 2, 0xFF2A1450, 0xFF1A0C38,
            new int[]{5, 6, 4, 5, 6}, 0xFFE8E8FF, true, 2600, 2, 0.3f, 0.9f, 24, 0.96f, 77,
            new int[]{0xFFB5179E, 0xFF3A86FF, 0xFFFF006E, 0xFF06D6A0}),
        new Tr("Manhattan Run", "New York", "Brooklyn Tony",
            0xFF7A8CA3, 0xFFD7DEE6, 0xFF6B6B70, 0xFF626268, 0xFF3C3C3F, 0xFF444447,
            0xFFF2C500, 0xFF111111, 5, 0xFF8B97A8, 0xFF5E6978,
            new int[]{5, 5, 6, 4, 5}, 0, false, 2400, 3, 0.2f, 1.6f, 26, 0.98f, 88,
            new int[]{0xFF6D7886, 0xFF8591A0, 0xFF58626F}),
    };
}
