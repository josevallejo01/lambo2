package com.anais.lambo2;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.Random;

/**
 * Lambo 2.0 - course arcade pseudo-3D (esprit Lamborghini American Challenge).
 * Zéro asset : route, décors, voitures et sons sont générés par code.
 * Rendu en basse résolution logique (640 px de large) puis mis à l'échelle : très léger.
 */
public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    // ------------------------------------------------------------ constantes
    static final int SEG = 200, ROAD = 2000, DRAW = 85, LINE_IDX = 24;
    static final float CAMH = 1000f, CAMD = 0.8391f, PZ = CAMH * CAMD;
    static final float CARW = 0.22f, BASE_MAX = 12000f;
    static final int MENU = 0, CD = 1, RACE = 2, RESULT = 3, GARAGE = 4;
    static final int[] BETS = {0, 100, 250, 500, 1000, 2500, 5000, 10000};
    static final float[] MODE_PROFIT = {1f, 0.5f, 2.5f};
    static final int[] PRIZE = {1000, 500, 250, 100, 0};
    static final String[] NAMES = {"Ace", "Lola", "Mad Max", "Sheriff", "Duke", "Nina", "Slick", "Bandit"};
    static final int[] RCOL = {0xFFD21F3C, 0xFFEDEDED, 0xFF2D6BFF, 0xFF2FBF4F};
    static final int[] TCOL = {0xFF8E9AA6, 0xFF3E5C76, 0xFF7B3F3F, 0xFFB5B5A0, 0xFF4F6D52, 0xFFC9C9C9};
    static final int[] SIGNC = {0xFFE53935, 0xFF1E88E5, 0xFFFDD835, 0xFF43A047};
    static final float[] SPR_W = {320, 520, 600, 700, 720, 1700, 180, 760};
    static final float[] SPR_H = {900, 1900, 1800, 420, 1300, 2600, 1700, 1400};

    // --- progression / contenu
    static final int[] REQ = {1, 2, 4, 6, 9, 12, 16, 20};
    static final boolean[] POLICE = {false, false, true, true, false, true, true, true};
    static final String[] ST = {"AZ", "TX", "FL", "CA", "CO", "IL", "NV", "NY"};
    static final String[] CARN = {"FURIA", "CORSA", "BLANCA", "AZZURRA"};
    static final int[] CARC = {0xFFFFD400, 0xFFD21F3C, 0xFFEDEDED, 0xFF2D6BFF};
    static final int[] CARL = {1, 5, 10, 15};
    static final float[] CARS = {1.00f, 1.04f, 1.08f, 1.12f};
    static final String[] UPN = {"MOTEUR", "PNEUS", "FREINS", "NITRO"};
    static final String[] UPD = {"Vitesse maximale", "Tenue de route", "Freinage", "Nitro : durée + puissance"};
    static final int[] XPP = {120, 80, 55, 30, 15};

    // carte stylisée des USA (coordonnées normalisées)
    static final float MAPX = 16f, MAPY = 60f, MAPW = 284f, MAPH = 170f;
    static final float[][] TPOS = {{0.20f, 0.62f}, {0.45f, 0.75f}, {0.82f, 0.85f}, {0.07f, 0.50f},
            {0.33f, 0.42f}, {0.62f, 0.32f}, {0.15f, 0.40f}, {0.88f, 0.20f}};
    static final float[] US = {0.03f, 0.10f, 0.30f, 0.12f, 0.58f, 0.12f, 0.63f, 0.18f, 0.72f, 0.13f, 0.82f, 0.12f,
            0.91f, 0.07f, 0.96f, 0.14f, 0.92f, 0.28f, 0.88f, 0.38f, 0.85f, 0.50f, 0.88f, 0.60f, 0.86f, 0.70f,
            0.89f, 0.84f, 0.92f, 0.95f, 0.86f, 0.97f, 0.80f, 0.85f, 0.76f, 0.74f, 0.66f, 0.74f, 0.60f, 0.82f,
            0.52f, 0.84f, 0.45f, 0.93f, 0.40f, 0.84f, 0.34f, 0.73f, 0.26f, 0.75f, 0.20f, 0.70f, 0.10f, 0.68f,
            0.04f, 0.60f, 0.02f, 0.45f, 0.01f, 0.30f};

    // zones tactiles (coordonnées de conception 640 x 288) : x, y, w, h
    static final int[] R_GAR = {300, 3, 100, 24}, R_LV = {170, 6, 120, 18};
    static final int[] R_TPREV = {16, 246, 44, 32}, R_TNEXT = {256, 246, 44, 32};
    static final int[] R_MODE = {324, 184, 300, 26}, R_BM = {324, 214, 40, 26}, R_BOX = {368, 214, 128, 26}, R_BP = {500, 214, 40, 26};
    static final int[] R_GO = {324, 246, 300, 32};
    static final int[] R_REP = {150, 236, 160, 44}, R_MEN = {330, 236, 160, 44};
    static final int[] R_BACK = {8, 3, 90, 24}, R_CPREV = {16, 246, 44, 32}, R_CUSE = {64, 246, 128, 32}, R_CNEXT = {196, 246, 44, 32};
    static final int[][] R_UP = {{540, 45, 84, 34}, {540, 95, 84, 34}, {540, 145, 84, 34}, {540, 195, 84, 34}};

    // ------------------------------------------------------------ types
    static final class Spr {
        int type, col;
        float off, ww, hh;
    }

    static final class Car {
        float off, z, speed, dist, finT, skill;
        int type, col, colD;
        boolean fin;
        String name;
    }

    static final class Pick {
        int type;
        float off;
        boolean taken;
    }

    static final class Seg {
        int index, color, special;
        float z1, z2, y1, y2, curve;
        float sx1, sy1, sw1, sc1, sx2, sy2, sw2, sc2, clip;
        boolean valid;
        final ArrayList<Car> cars = new ArrayList<Car>(2);
        ArrayList<Spr> spr;
        ArrayList<Pick> pk;
    }

    // ------------------------------------------------------------ champs
    final Object lock = new Object();
    Thread th;
    volatile boolean running;
    int W = 640, H = 360;
    float oy;
    final Paint p = new Paint(), tp = new Paint(Paint.ANTI_ALIAS_FLAG), pSky = new Paint(), pHaze = new Paint();
    final Path path = new Path();
    final Random rnd = new Random();
    final SharedPreferences prefs;

    // sauvegarde
    int cash = 2000, eng = 0, tire = 0, selTrack = 0, betIdx = 3, betMode = 0;
    final float[] best = new float[Tr.ALL.length];

    // thème
    Tr tr;
    Shader skySh, hazeSh;
    final Path bgFar = new Path(), bgNear = new Path(), bgX = new Path();
    float[] stars = new float[0];
    float hazeH, bg1, bg2;

    // piste
    Seg[] segs;
    int N;
    float L;
    ArrayList<Seg> bl;
    float bY;
    final ArrayList<Car> cars = new ArrayList<Car>();
    final ArrayList<Car> rivals = new ArrayList<Car>();

    // état de jeu
    int state = MENU;
    boolean paused;
    float pos, totalDist, speed, playerX, maxSpeed, steer, cent, offLim, finishDist, lineOff;
    float raceT, cd, goT, nitroT, shake, lean, finT, hint, resT, horizon;
    int nitros, bet, place, lapNow, prize, profit;
    boolean finished, betWon, loan, newRecord;
    ArrayList<Car> order = new ArrayList<Car>();

    // progression
    int xp = 0, selCar = 0, viewCar = 0, upBrk = 0, upNit = 0, xpGain = 0, picks = 0, fines = 0, msgCol;
    boolean levelUp;
    final boolean[] pod = new boolean[Tr.ALL.length];
    float brakeF = 1f, nitroDur = 2.2f, nitroPow = 1f, damage, shield, msgT, flash, policeT;
    String msg;
    Car police;
    final Path bgTrees = new Path();
    float[] prev = new float[0];
    float prevW = 1f, prevH = 1f;
    AudioTrack sir;

    // entrées
    volatile boolean left, right, brake, nitroReq;
    boolean nitroPrev;

    // audio
    AudioTrack at;
    static final int AT_SR = 22050;

    // ------------------------------------------------------------ construction
    public GameView(Context ctx) {
        super(ctx);
        getHolder().addCallback(this);
        setFocusable(true);
        prefs = ctx.getSharedPreferences("lambo2", Context.MODE_PRIVATE);
        cash = prefs.getInt("cash", 2000);
        eng = prefs.getInt("eng", 0);
        tire = prefs.getInt("tire", 0);
        selTrack = Math.max(0, Math.min(Tr.ALL.length - 1, prefs.getInt("trk", 0)));
        betIdx = Math.max(0, Math.min(BETS.length - 1, prefs.getInt("bet", 3)));
        betMode = Math.max(0, Math.min(2, prefs.getInt("mode", 0)));
        for (int i = 0; i < best.length; i++) best[i] = prefs.getFloat("b" + i, 0f);
        xp = prefs.getInt("xp", 0);
        selCar = Math.max(0, Math.min(3, prefs.getInt("car", 0)));
        upBrk = prefs.getInt("brk", 0);
        upNit = prefs.getInt("nit", 0);
        for (int i = 0; i < pod.length; i++) pod[i] = prefs.getBoolean("p" + i, false);
        if (level() < CARL[selCar]) selCar = 0;
        viewCar = selCar;
        tp.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        tp.setShadowLayer(2f, 1f, 1f, 0xAA000000);
        initTheme();
        buildPreview();
    }

    void saveAll() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("cash", cash).putInt("eng", eng).putInt("tire", tire).putInt("trk", selTrack)
                .putInt("bet", betIdx).putInt("mode", betMode)
                .putInt("xp", xp).putInt("car", selCar).putInt("brk", upBrk).putInt("nit", upNit);
        for (int i = 0; i < pod.length; i++) e.putBoolean("p" + i, pod[i]);
        for (int i = 0; i < best.length; i++) e.putFloat("b" + i, best[i]);
        e.apply();
    }

    // ------------------------------------------------------------ cycle de vie
    @Override
    public void surfaceCreated(SurfaceHolder h) {
        running = true;
        th = new Thread(this, "game");
        th.start();
        initAudio();
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        running = false;
        try {
            if (th != null) th.join();
        } catch (InterruptedException e) {
            // ignore
        }
        th = null;
        stopAudio();
        pauseGame();
    }

    void pauseGame() {
        synchronized (lock) {
            if (state == RACE || state == CD) paused = true;
        }
    }

    boolean onBack() {
        synchronized (lock) {
            if (state == MENU) return false;
            if (state == GARAGE) {
                state = MENU;
                return true;
            }
            if (state == RESULT) {
                state = MENU;
                return true;
            }
            if (!paused) {
                paused = true;
                return true;
            }
            if (bet > 0 && !finished) {
                cash -= bet;
                if (cash < 100) cash = 300;
                saveAll();
            }
            paused = false;
            state = MENU;
            return true;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        int nh;
        synchronized (lock) {
            W = 640;
            nh = Math.max(270, Math.round(640f * h / w));
            H = nh;
            oy = Math.max(0f, (H - 288) / 2f);
            initTheme();
        }
        getHolder().setFixedSize(640, nh);
    }

    @Override
    public void run() {
        long last = System.nanoTime();
        int frame = 0;
        while (running) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            SurfaceHolder h = getHolder();
            Canvas c = null;
            try {
                c = h.lockCanvas();
                if (c != null) {
                    synchronized (lock) {
                        update(dt);
                        drawGame(c);
                        if ((++frame & 3) == 0) audio();
                    }
                }
            } catch (Exception e) {
                // on ignore une image ratée
            } finally {
                if (c != null) {
                    try {
                        h.unlockCanvasAndPost(c);
                    } catch (Exception e) {
                        // ignore
                    }
                }
            }
            long ms = (System.nanoTime() - now) / 1000000L;
            if (ms < 16) {
                try {
                    Thread.sleep(16 - ms);
                } catch (InterruptedException e) {
                    // ignore
                }
            }
        }
    }

    // ------------------------------------------------------------ entrées
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        int idx = e.getActionIndex();
        float vw = Math.max(1, getWidth()), vh = Math.max(1, getHeight());
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            float tx = e.getX(idx) * W / vw, ty = e.getY(idx) * H / vh;
            synchronized (lock) {
                onTap(tx, ty);
            }
        }
        boolean l = false, r = false, b = false, n = false;
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            int up = act == MotionEvent.ACTION_POINTER_UP ? idx : -1;
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == up) continue;
                float fx = e.getX(i) / vw, fy = e.getY(i) / vh;
                if (fx < 0.34f) l = true;
                else if (fx > 0.66f) r = true;
                else if (fy > 0.5f) n = true;
                else b = true;
            }
        }
        left = l;
        right = r;
        brake = b;
        if (n && !nitroPrev) nitroReq = true;
        nitroPrev = n;
        return true;
    }

    static boolean hit(int[] r, float x, float y) {
        return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
    }

    void onTap(float x, float y) {
        if (paused) {
            paused = false;
            return;
        }
        float ty = y - oy;
        if (state == MENU) tapMenu(x, ty);
        else if (state == GARAGE) tapGarage(x, ty);
        else if (state == RESULT && resT > 0.6f) tapResult(x, ty);
    }

    static int cost(int level) {
        return 1500 * (level + 1);
    }

    static int need(int lv) {
        return 80 + 20 * lv;
    }

    int level() {
        int lv = 1, rem = xp;
        while (lv < 30 && rem >= need(lv)) {
            rem -= need(lv);
            lv++;
        }
        return lv;
    }

    float lvFrac() {
        int lv = 1, rem = xp;
        while (lv < 30 && rem >= need(lv)) {
            rem -= need(lv);
            lv++;
        }
        return lv >= 30 ? 1f : rem / (float) need(lv);
    }

    boolean unlocked(int i) {
        return level() >= REQ[i] && (i == 0 || pod[i - 1]);
    }

    int upLv(int i) {
        return i == 0 ? eng : (i == 1 ? tire : (i == 2 ? upBrk : upNit));
    }

    void buyUp(int i) {
        int l = upLv(i);
        if (l >= 5 || cash < cost(l)) return;
        cash -= cost(l);
        if (i == 0) eng++;
        else if (i == 1) tire++;
        else if (i == 2) upBrk++;
        else upNit++;
        saveAll();
    }

    void selectTrack() {
        initTheme();
        buildPreview();
        saveAll();
    }

    /** Petit tracé du circuit (intégration des virages), pour l'aperçu. */
    void buildPreview() {
        buildTrack();
        int step = 6, m = N / step;
        prev = new float[m * 2];
        float ang = 0, x = 0, y = 0;
        float minX = 1e9f, maxX = -1e9f, minY = 1e9f, maxY = -1e9f;
        for (int i = 0; i < m; i++) {
            float cv = 0;
            for (int j = 0; j < step; j++) cv += segs[i * step + j].curve;
            ang += cv * 0.014f;
            x += (float) Math.cos(ang);
            y += (float) Math.sin(ang);
            prev[i * 2] = x;
            prev[i * 2 + 1] = y;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        float sc = Math.max(1f, Math.max(maxX - minX, maxY - minY));
        for (int i = 0; i < m; i++) {
            prev[i * 2] = (prev[i * 2] - minX) / sc;
            prev[i * 2 + 1] = (prev[i * 2 + 1] - minY) / sc;
        }
        prevW = Math.max(0.05f, (maxX - minX) / sc);
        prevH = Math.max(0.05f, (maxY - minY) / sc);
    }

    void tapMenu(float x, float y) {
        int n = Tr.ALL.length;
        if (hit(R_GAR, x, y)) {
            viewCar = selCar;
            state = GARAGE;
            return;
        }
        if (hit(R_TPREV, x, y)) {
            selTrack = (selTrack + n - 1) % n;
            selectTrack();
            return;
        }
        if (hit(R_TNEXT, x, y)) {
            selTrack = (selTrack + 1) % n;
            selectTrack();
            return;
        }
        int bi = -1;
        float bd = 22f;
        for (int i = 0; i < n; i++) {
            float dx = x - (MAPX + TPOS[i][0] * MAPW), dy = y - (MAPY + TPOS[i][1] * MAPH);
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < bd) {
                bd = d;
                bi = i;
            }
        }
        if (bi >= 0) {
            selTrack = bi;
            selectTrack();
            return;
        }
        if (hit(R_MODE, x, y)) {
            betMode = (betMode + 1) % 3;
            saveAll();
        } else if (hit(R_BM, x, y)) {
            if (betIdx > 0) betIdx--;
        } else if (hit(R_BP, x, y)) {
            if (betIdx < BETS.length - 1 && BETS[betIdx + 1] <= cash) betIdx++;
        } else if (hit(R_GO, x, y)) {
            if (unlocked(selTrack)) startRace();
        }
    }

    void tapGarage(float x, float y) {
        if (hit(R_BACK, x, y)) {
            state = MENU;
            return;
        }
        if (hit(R_CPREV, x, y)) viewCar = (viewCar + 3) % 4;
        else if (hit(R_CNEXT, x, y)) viewCar = (viewCar + 1) % 4;
        else if (hit(R_CUSE, x, y)) {
            if (level() >= CARL[viewCar]) {
                selCar = viewCar;
                saveAll();
            }
        } else {
            for (int i = 0; i < 4; i++) if (hit(R_UP[i], x, y)) buyUp(i);
        }
    }

    void tapResult(float x, float y) {
        if (hit(R_REP, x, y)) startRace();
        else if (hit(R_MEN, x, y)) state = MENU;
    }

    // ------------------------------------------------------------ bonus et police
    float policeGap() {
        if (police == null) return 1e9f;
        float g = (pos + PZ) % L - police.z;
        if (g > L / 2) g -= L;
        else if (g < -L / 2) g += L;
        return g;
    }

    void collect(Pick k) {
        flash = 0.2f;
        msgT = 1.6f;
        picks++;
        if (k.type == 0) {
            damage = Math.max(0f, damage - 35f);
            shield = 4f;
            msg = "COEUR : REPARATION + BOUCLIER";
            msgCol = 0xFFFF5A6E;
        } else if (k.type == 1) {
            if (nitros < 5) nitros++;
            nitroT = Math.max(nitroT, 1.2f);
            msg = "NITRO !";
            msgCol = 0xFF38B6FF;
        } else {
            int v = (int) ((20 + rnd.nextInt(61)) * (1f + selTrack * 0.25f));
            cash += v;
            msg = "+" + money(v);
            msgCol = 0xFFFFD400;
        }
    }

    void spawnPolice() {
        Car k = new Car();
        k.type = 3;
        k.col = 0xFFF2F2F2;
        k.colD = 0xFF202020;
        k.name = "POLICE";
        float nz = (pos + PZ) % L - 4500f;
        if (nz < 0) nz += L;
        k.z = nz;
        k.off = Math.max(-0.7f, Math.min(0.7f, playerX));
        k.speed = speed * 0.9f;
        police = k;
        cars.add(k);
        seg(nz).cars.add(k);
        msg = "POLICE DERRIERE TOI !";
        msgCol = 0xFFFF6B6B;
        msgT = 1.8f;
    }

    void removePolice() {
        if (police == null) return;
        seg(police.z).cars.remove(police);
        cars.remove(police);
        police = null;
    }

    void updateExtras(float dt) {
        if (shield > 0) shield -= dt;
        if (msgT > 0) msgT -= dt;
        if (flash > 0) flash -= dt;
        if (finished) return;
        // bonus : on contrôle les 3 derniers segments traversés
        Seg q = seg(pos + PZ);
        for (int d = 0; d < 3; d++) {
            Seg s2 = segs[(q.index - d + N) % N];
            if (s2.pk == null) continue;
            for (int i = 0; i < s2.pk.size(); i++) {
                Pick k = s2.pk.get(i);
                if (!k.taken && ov(playerX, CARW, k.off, 0.25f, 1.1f)) {
                    k.taken = true;
                    collect(k);
                }
            }
        }
        // police
        if (!POLICE[selTrack]) return;
        if (police == null) {
            policeT -= dt;
            if (policeT <= 0f && raceT > 8f) spawnPolice();
            return;
        }
        float gap = policeGap();
        if (gap > 13000f) {
            removePolice();
            policeT = 25f;
            cash += 200;
            msg = "POLICE SEMEE ! +$200";
            msgCol = 0xFF5CE08A;
            msgT = 1.8f;
        } else if (gap < 260f && shield <= 0f && Math.abs(police.off - playerX) < 0.35f) {
            int fine = Math.min(cash, 300);
            cash -= fine;
            fines += fine;
            speed *= 0.35f;
            damage = Math.min(100f, damage + 8f);
            shake = 0.5f;
            flash = 0.2f;
            float nz = police.z - 7000f;
            if (nz < 0) nz += L;
            moveCar(police, seg(police.z), nz);
            police.speed = speed;
            msg = "AMENDE -" + money(fine);
            msgCol = 0xFFFF6B6B;
            msgT = 1.8f;
        }
    }

    // ------------------------------------------------------------ thème visuel
    void initTheme() {
        tr = Tr.ALL[selTrack];
        skySh = new LinearGradient(0, 0, 0, H * 0.55f, tr.skyT, tr.skyB, Shader.TileMode.CLAMP);
        int fog = tr.skyB & 0x00FFFFFF;
        hazeH = H * 0.28f;
        hazeSh = new LinearGradient(0, 0, 0, hazeH, fog | 0xE6000000, fog, Shader.TileMode.CLAMP);
        Random r = new Random(tr.seed * 31L + 7L);
        bgFar.reset();
        bgNear.reset();
        bgX.reset();
        bgTrees.reset();
        makeBg(bgFar, null, r, 0.6f, false);
        makeBg(bgNear, bgX, r, 1f, tr.night);
        if (tr.bg == 3 || tr.bg == 4) {
            float tx = 2;
            while (tx < W - 10) {
                float th = 12 + r.nextInt(18);
                bgTrees.moveTo(tx - 5, 0);
                bgTrees.lineTo(tx + 5, 0);
                bgTrees.lineTo(tx, -th);
                bgTrees.close();
                tx += 7 + r.nextInt(9);
            }
        }
        if (tr.night) {
            stars = new float[100];
            for (int i = 0; i < stars.length; i += 2) {
                stars[i] = r.nextFloat() * W;
                stars[i + 1] = r.nextFloat() * H * 0.42f;
            }
        } else {
            stars = new float[0];
        }
    }

    void makeBg(Path main, Path extra, Random r, float k, boolean win) {
        float T = W;
        switch (tr.bg) {
            case 0: { // mesas
                main.addRect(0, -6f * k - 2f, T, 0, Path.Direction.CW);
                float x = 4 + r.nextInt(30);
                while (true) {
                    float w = (60 + r.nextInt(90)) * k + 16, h = (35 + r.nextInt(55)) * k + 8;
                    if (x + w > T - 6) break;
                    main.moveTo(x, 0);
                    main.lineTo(x + w * 0.1f, -h);
                    main.lineTo(x + w * 0.9f, -h);
                    main.lineTo(x + w, 0);
                    main.close();
                    x += w + 8 + r.nextInt(50);
                }
                break;
            }
            case 1:
            case 2:
            case 5: { // villes
                float x = 0;
                while (x < T) {
                    float w = 14 + r.nextInt(26);
                    float h = (tr.bg == 5 ? 50 + r.nextInt(120) : 18 + r.nextInt(60)) * k;
                    if (x + w > T) w = T - x;
                    main.addRect(x, -h, x + w, 0, Path.Direction.CW);
                    if (win && extra != null) {
                        for (float yy = -h + 5; yy < -5; yy += 8) {
                            for (float xx = x + 3; xx < x + w - 5; xx += 7) {
                                if (r.nextInt(3) == 0) extra.addRect(xx, yy, xx + 3, yy + 3, Path.Direction.CW);
                            }
                        }
                    }
                    x += w + r.nextInt(3);
                }
                break;
            }
            case 3: { // collines
                int n = 6;
                float step = T / n;
                float[] ys = new float[n + 1];
                for (int i = 0; i < n; i++) ys[i] = -((25 + r.nextInt(50)) * k + 8);
                ys[n] = ys[0];
                main.moveTo(0, 0);
                main.lineTo(0, ys[0]);
                for (int i = 0; i < n; i++) {
                    float x0 = i * step, x1 = (i + 1) * step;
                    main.cubicTo(x0 + step * 0.5f, ys[i], x0 + step * 0.5f, ys[i + 1], x1, ys[i + 1]);
                }
                main.lineTo(T, 0);
                main.close();
                break;
            }
            default: { // montagnes enneigées
                float h0 = (30 + r.nextInt(30)) * k + 8, x = 0;
                main.moveTo(0, 0);
                main.lineTo(0, -h0);
                while (x < T - 80) {
                    x += 25 + r.nextInt(25);
                    float ph = (55 + r.nextInt(80)) * k + 12;
                    main.lineTo(x, -ph);
                    if (extra != null) {
                        extra.moveTo(x, -ph);
                        extra.lineTo(x + 9, -ph + 15);
                        extra.lineTo(x + 3, -ph + 11);
                        extra.lineTo(x - 3, -ph + 16);
                        extra.lineTo(x - 9, -ph + 15);
                        extra.close();
                    }
                    x += 25 + r.nextInt(25);
                    main.lineTo(x, -((12 + r.nextInt(22)) * k + 6));
                }
                main.lineTo(T, -h0);
                main.lineTo(T, 0);
                main.close();
                break;
            }
        }
    }

    // ------------------------------------------------------------ génération de piste
    static float ein(float a, float b, float q) {
        return a + (b - a) * q * q;
    }

    static float eio(float a, float b, float q) {
        return a + (b - a) * ((float) (-Math.cos(q * Math.PI) / 2) + 0.5f);
    }

    void addSeg(float curve, float y) {
        Seg s = new Seg();
        int n = bl.size();
        s.index = n;
        s.z1 = n * (float) SEG;
        s.z2 = (n + 1) * (float) SEG;
        s.y1 = bY;
        s.y2 = y;
        s.curve = curve;
        s.color = (n / 3) % 2;
        bl.add(s);
        bY = y;
    }

    void addRoad(int en, int ho, int le, float curve, float y) {
        float sy = bY, ey = sy + y * SEG;
        float tot = en + ho + le;
        for (int i = 0; i < en; i++) addSeg(ein(0, curve, i / (float) en), eio(sy, ey, i / tot));
        for (int i = 0; i < ho; i++) addSeg(curve, eio(sy, ey, (en + i) / tot));
        for (int i = 0; i < le; i++) addSeg(eio(curve, 0, i / (float) le), eio(sy, ey, (en + ho + i) / tot));
    }

    void buildTrack() {
        Random r = new Random(tr.seed);
        bl = new ArrayList<Seg>();
        bY = 0;
        addRoad(0, 30, 0, 0f, 0f);
        while (bl.size() < tr.len - 260) {
            int k = r.nextInt(8);
            int e = 18 + r.nextInt(25), h = 20 + r.nextInt(60), l = 18 + r.nextInt(25);
            float cur = (1.5f + r.nextFloat() * 3.5f) * tr.curve * (r.nextBoolean() ? 1 : -1);
            float dir = bY > 0 ? (r.nextFloat() < 0.65f ? -1 : 1) : (r.nextFloat() < 0.65f ? 1 : -1);
            float hy = tr.hill * (8 + r.nextInt(30)) * dir;
            switch (k) {
                case 0:
                    addRoad(10, 20 + r.nextInt(30), 10, 0f, 0f);
                    break;
                case 1:
                case 2:
                case 3:
                    addRoad(e, h, l, cur, 0f);
                    break;
                case 4:
                    addRoad(e, h, l, 0f, hy);
                    break;
                case 5:
                    addRoad(e, h, l, cur, hy);
                    break;
                case 6:
                    addRoad(e, h, l, cur, 0f);
                    addRoad(e, h, l, -cur, 0f);
                    break;
                default:
                    addRoad(25, 25, 25, 0f, hy * 0.5f);
                    addRoad(25, 25, 25, 0f, -hy * 0.4f);
                    break;
            }
        }
        addRoad(25, 25, 25, 0f, -bY / SEG);
        addRoad(0, 20, 0, 0f, 0f);
        bl.get(bl.size() - 1).y2 = 0f;

        segs = bl.toArray(new Seg[0]);
        N = segs.length;
        L = N * (float) SEG;
        for (Seg s : segs) s.special = s.index == LINE_IDX ? 1 : (s.index == LINE_IDX + 1 ? 2 : 0);

        // décor
        for (int n = 6; n < N; n += 2 + r.nextInt(4)) {
            int sides = r.nextInt(3);
            for (int sd = 0; sd < 2; sd++) {
                if (sides != 2 && sides != sd) continue;
                int t = tr.objs[r.nextInt(tr.objs.length)];
                Spr o = new Spr();
                o.type = t;
                float jw = 0.85f + r.nextFloat() * 0.4f;
                o.ww = SPR_W[t] * jw;
                o.hh = SPR_H[t] * (t == 5 ? 0.6f + r.nextFloat() * 0.9f : jw);
                float side = sd == 0 ? -1f : 1f;
                float far = r.nextInt(100) < 18 ? 2.5f + r.nextFloat() * 3f : r.nextFloat() * 0.8f;
                o.off = side * (1.2f + o.ww / ROAD * 0.5f + far);
                o.col = t == 5 ? tr.bcols[r.nextInt(tr.bcols.length)] : (t == 4 ? SIGNC[r.nextInt(SIGNC.length)] : 0);
                Seg s = segs[n];
                if (s.spr == null) s.spr = new ArrayList<Spr>(2);
                s.spr.add(o);
            }
        }

        // bonus : cœur / nitro / argent, sur les voies
        float[] ln = {-0.66f, 0f, 0.66f};
        for (int n = 40; n < N - 10; n += 40 + r.nextInt(40)) {
            Pick k = new Pick();
            int t = r.nextInt(100);
            k.type = t < 50 ? 2 : (t < 75 ? 1 : 0);
            k.off = ln[r.nextInt(3)];
            Seg s = segs[n];
            if (s.pk == null) s.pk = new ArrayList<Pick>(1);
            s.pk.add(k);
        }
    }

    Seg seg(float z) {
        return segs[((int) (z / SEG)) % N];
    }

    // ------------------------------------------------------------ démarrage de course
    void startRace() {
        if (!unlocked(selTrack)) return;
        while (betIdx > 0 && BETS[betIdx] > cash) betIdx--;
        bet = BETS[betIdx];
        tr = Tr.ALL[selTrack];
        buildTrack();
        maxSpeed = BASE_MAX * (1f + 0.05f * eng) * CARS[selCar];
        brakeF = 1f + 0.2f * upBrk;
        nitroDur = 2.2f + 0.35f * upNit;
        nitroPow = 1f + 0.12f * upNit;
        damage = 0;
        shield = 0;
        msgT = 0;
        flash = 0;
        police = null;
        policeT = 18f;
        picks = 0;
        fines = 0;
        steer = 1f + 0.08f * tire;
        cent = 0.3f * (1f - 0.07f * tire);
        offLim = maxSpeed * (0.25f + 0.03f * tire);
        lineOff = LINE_IDX * SEG - PZ;
        finishDist = lineOff + tr.laps * L;
        pos = 0;
        totalDist = 0;
        speed = 0;
        playerX = 0;
        nitros = 3;
        nitroT = 0;
        raceT = 0;
        finished = false;
        shake = 0;
        lean = 0;
        hint = 8f;
        cd = 3.4f;
        goT = 0;
        finT = 0;
        lapNow = 1;
        paused = false;
        left = false;
        right = false;
        brake = false;
        nitroReq = false;
        spawnCars();
        saveAll();
        state = CD;
    }

    void spawnCars() {
        cars.clear();
        rivals.clear();
        Random r = new Random();
        ArrayList<String> pool = new ArrayList<String>();
        for (String n : NAMES) if (!n.equals(tr.boss)) pool.add(n);
        Collections.shuffle(pool, r);
        float[] offs = {-0.55f, 0.55f, -0.55f, 0.55f};
        float[] ds = {450f, 450f, 900f, 900f};
        for (int k = 0; k < 4; k++) {
            Car c = new Car();
            c.type = 2;
            c.off = offs[k];
            c.dist = ds[k];
            c.z = (c.dist + PZ) % L;
            c.col = RCOL[k];
            c.colD = shade(c.col, 0.68f);
            c.skill = 0.97f + r.nextFloat() * 0.05f;
            c.name = k == 0 ? tr.boss : pool.get(k - 1);
            rivals.add(c);
            cars.add(c);
            seg(c.z).cars.add(c);
        }
        float[] lanes = {-0.66f, 0f, 0.66f};
        for (int i = 0; i < tr.traffic; i++) {
            Car c = new Car();
            c.type = r.nextInt(100) < 18 ? 1 : 0;
            c.z = 5600f + r.nextFloat() * (L - 6600f);
            c.off = lanes[r.nextInt(3)] + (r.nextFloat() - 0.5f) * 0.2f;
            c.speed = BASE_MAX * (0.16f + r.nextFloat() * 0.26f) * (c.type == 1 ? 0.8f : 1f);
            c.col = c.type == 1 ? 0xFFE8E8E0 : TCOL[r.nextInt(TCOL.length)];
            c.colD = shade(c.col, 0.68f);
            cars.add(c);
            seg(c.z).cars.add(c);
        }
    }

    static int shade(int c, float f) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * f));
        int g = Math.min(255, (int) (((c >> 8) & 255) * f));
        int b = Math.min(255, (int) ((c & 255) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------ mise à jour
    void update(float dt) {
        if (paused) return;
        switch (state) {
            case MENU:
            case GARAGE:
                bg1 += dt * 7f;
                bg2 += dt * 14f;
                while (betIdx > 0 && BETS[betIdx] > cash) betIdx--;
                break;
            case CD:
                cd -= dt;
                updateCars(dt, true);
                if (cd <= 0.4f) {
                    state = RACE;
                    goT = 0.9f;
                }
                break;
            case RACE:
                updateRace(dt);
                break;
            default:
                resT += dt;
                break;
        }
    }

    static boolean ov(float x1, float w1, float x2, float w2, float pct) {
        float half = pct / 2f;
        float min1 = x1 - w1 * half, max1 = x1 + w1 * half;
        float min2 = x2 - w2 * half, max2 = x2 + w2 * half;
        return !(max1 < min2 || min1 > max2);
    }

    void updateRace(float dt) {
        Seg ps = seg(pos + PZ);
        float eff = maxSpeed * (1f - 0.25f * damage / 100f);
        float curMax = eff * (nitroT > 0 ? 1.25f + 0.02f * upNit : 1f);
        float pct = speed / maxSpeed;
        float dxs = dt * 2f * pct;
        float adv = dt * speed;
        pos += adv;
        totalDist += adv;
        if (pos >= L) pos -= L;

        float tl = (right ? 1f : 0f) - (left ? 1f : 0f);
        lean += (tl - lean) * Math.min(1f, dt * 8f);

        if (!finished) {
            raceT += dt;
            if (tl < 0) playerX -= dxs * steer;
            else if (tl > 0) playerX += dxs * steer;
            playerX -= dxs * pct * ps.curve * cent;
            if (nitroReq) {
                if (nitros > 0 && nitroT <= 0) {
                    nitros--;
                    nitroT = nitroDur;
                }
                nitroReq = false;
            }
            float acc = nitroT > 0 ? maxSpeed / 1.5f * nitroPow : maxSpeed / 4f;
            if (brake) speed -= maxSpeed * brakeF * dt;
            else speed += acc * dt;
        } else {
            speed -= maxSpeed * 0.4f * dt;
            finT += dt;
            if (finT > 2.2f) {
                state = RESULT;
                resT = 0;
            }
        }
        if (nitroT > 0) nitroT -= dt;
        if (speed > curMax) speed = Math.max(curMax, speed - maxSpeed * 0.3f * dt);
        if ((playerX < -1f || playerX > 1f) && speed > offLim) speed -= maxSpeed * 0.5f * dt;

        Seg q = seg(pos + PZ);
        // collisions avec le décor (hors route)
        if ((playerX < -1f || playerX > 1f) && q.spr != null) {
            for (int i = 0; i < q.spr.size(); i++) {
                Spr o = q.spr.get(i);
                if (shield <= 0f && ov(playerX, CARW, o.off, o.ww / ROAD, 1f)) {
                    if (speed > maxSpeed * 0.2f) {
                        shake = 0.4f;
                        damage = Math.min(100f, damage + 6f);
                    }
                    speed = Math.min(speed, maxSpeed * 0.12f);
                }
            }
        }
        // collisions avec les voitures
        for (int i = 0; i < q.cars.size(); i++) {
            Car k = q.cars.get(i);
            if (k.type != 3 && shield <= 0f && speed > k.speed && ov(playerX, CARW, k.off, CARW, 0.8f)) {
                speed = k.speed * (k.speed / Math.max(1f, speed));
                float np = k.z - PZ;
                if (np < 0) np += L;
                float d = np - pos;
                if (d > L / 2) d -= L;
                else if (d < -L / 2) d += L;
                pos = np;
                totalDist += d;
                shake = 0.35f;
                damage = Math.min(100f, damage + 10f);
                break;
            }
        }
        if (playerX < -3f) playerX = -3f;
        else if (playerX > 3f) playerX = 3f;
        if (speed < 0) speed = 0;

        updateCars(dt, false);
        updateExtras(dt);

        bg1 += ps.curve * pct * dt * 30f;
        bg2 += ps.curve * pct * dt * 60f;
        if (shake > 0) shake -= dt;
        if (hint > 0) hint -= dt;
        if (goT > 0) goT -= dt;
        float ld = (totalDist - lineOff) / L;
        lapNow = ld < 0 ? 1 : Math.min(tr.laps, (int) ld + 1);

        if (!finished && totalDist >= finishDist) {
            finished = true;
            finT = 0;
            finishRace();
        }
    }

    void moveCar(Car k, Seg old, float nz) {
        Seg nw = seg(nz);
        k.z = nz;
        if (old != nw) {
            old.cars.remove(k);
            nw.cars.add(k);
        }
    }

    float steerOff(Car k, Seg cs, Seg ps) {
        int di = (cs.index - ps.index + N) % N;
        if (di > DRAW) return 0f;
        for (int i = 1; i < 20; i++) {
            Seg s = segs[(cs.index + i) % N];
            if (s == ps && k.speed > speed && ov(playerX, CARW, k.off, CARW, 1.2f)) {
                float dir = playerX > 0.5f ? -1f : (playerX < -0.5f ? 1f : (k.off > playerX ? 1f : -1f));
                return dir / i * (k.speed - speed) / BASE_MAX;
            }
            for (int j = 0; j < s.cars.size(); j++) {
                Car o = s.cars.get(j);
                if (o != k && k.speed > o.speed && ov(k.off, CARW, o.off, CARW, 1.2f)) {
                    float dir = o.off > 0.5f ? -1f : (o.off < -0.5f ? 1f : (k.off > o.off ? 1f : -1f));
                    return dir / i * (k.speed - o.speed) / BASE_MAX;
                }
            }
        }
        if (k.off < -0.8f) return 0.1f;
        if (k.off > 0.8f) return -0.1f;
        return 0f;
    }

    void updateCars(float dt, boolean frozen) {
        Seg ps = seg(pos + PZ);
        for (int i = 0; i < cars.size(); i++) {
            Car k = cars.get(i);
            Seg cs = seg(k.z);
            if (k.type == 2) {
                if (frozen) {
                    k.speed = 0;
                    continue;
                }
                float gap = totalDist - k.dist;
                float boost = Math.max(-0.06f, Math.min(0.12f, gap / 9000f));
                float target = BASE_MAX * tr.rp * k.skill * (1f + boost);
                k.speed += (target - k.speed) * Math.min(1f, dt * 1.5f);
                k.off += steerOff(k, cs, ps) * dt * 60f;
                if (k.off < -0.9f) k.off = -0.9f;
                else if (k.off > 0.9f) k.off = 0.9f;
                k.dist += dt * k.speed;
                if (!k.fin && k.dist >= finishDist) {
                    k.fin = true;
                    k.finT = raceT;
                }
                moveCar(k, cs, (k.dist + PZ) % L);
            } else if (k.type == 3) {
                if (frozen) continue;
                float gap = policeGap();
                float target = BASE_MAX * 0.92f * (gap > 2500f ? 1.1f : 1f);
                if (gap < -200f) target = BASE_MAX * 0.5f;
                k.speed += (target - k.speed) * Math.min(1f, dt * 1.2f);
                k.off += (Math.max(-0.7f, Math.min(0.7f, playerX)) - k.off) * Math.min(1f, dt * 0.8f);
                float pz2 = k.z + dt * k.speed;
                if (pz2 >= L) pz2 -= L;
                moveCar(k, cs, pz2);
            } else {
                if (frozen) continue;
                float nz = k.z + dt * k.speed;
                if (nz >= L) nz -= L;
                moveCar(k, cs, nz);
            }
        }
    }

    int curPlace() {
        int pl = 1;
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            if (k.fin || k.dist > totalDist) pl++;
        }
        return pl;
    }

    void finishRace() {
        ArrayList<Car> fin = new ArrayList<Car>(), rest = new ArrayList<Car>();
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            if (k.fin) fin.add(k);
            else rest.add(k);
        }
        Collections.sort(fin, new Comparator<Car>() {
            @Override
            public int compare(Car a, Car b) {
                return Float.compare(a.finT, b.finT);
            }
        });
        Collections.sort(rest, new Comparator<Car>() {
            @Override
            public int compare(Car a, Car b) {
                return Float.compare(b.dist, a.dist);
            }
        });
        order = new ArrayList<Car>();
        order.addAll(fin);
        order.add(null);
        order.addAll(rest);
        place = fin.size() + 1;
        int bossPlace = order.indexOf(rivals.get(0)) + 1;
        prize = (int) (PRIZE[Math.min(4, place - 1)] * (1f + selTrack * 0.4f));
        int lvBefore = level();
        xpGain = (int) (XPP[Math.min(4, place - 1)] * (1f + selTrack * 0.25f)) + picks * 5;
        xp += xpGain;
        levelUp = level() > lvBefore;
        if (place <= 3) pod[selTrack] = true;
        betWon = false;
        profit = 0;
        if (bet > 0) {
            if (betMode == 0) betWon = place < bossPlace;
            else if (betMode == 1) betWon = place <= 3;
            else betWon = place == 1;
            if (betWon) profit = (int) (bet * MODE_PROFIT[betMode]);
        }
        cash += prize + profit - (bet > 0 && !betWon ? bet : 0);
        loan = false;
        if (cash < 100) {
            cash = 300;
            loan = true;
        }
        newRecord = best[selTrack] <= 0f || raceT < best[selTrack];
        if (newRecord) best[selTrack] = raceT;
        saveAll();
    }

    // ------------------------------------------------------------ dessin
    private void drawGame(Canvas c) {
        c.drawColor(0xFF000000);
        if (state == MENU || state == GARAGE) {
            drawBg(c);
            c.drawColor(0xC8000000);
            if (state == MENU) drawMenu(c);
            else drawGarage(c);
            return;
        }
        c.save();
        if (shake > 0) c.translate((rnd.nextFloat() - 0.5f) * 7f, (rnd.nextFloat() - 0.5f) * 5f);
        drawWorld(c);
        c.restore();
        drawHud(c);
        if (state == CD) {
            int n = (int) Math.ceil(cd - 0.4f);
            txt(c, String.valueOf(Math.max(1, n)), W / 2f, H * 0.5f, 90, 0xFFFFFFFF, Paint.Align.CENTER);
        }
        if (state == RESULT) drawResult(c);
        if (paused) {
            c.drawColor(0xB0000000);
            txt(c, "PAUSE", W / 2f, H * 0.45f, 52, 0xFFFFD400, Paint.Align.CENTER);
            txt(c, "Touche l'écran pour reprendre  ·  Retour pour abandonner", W / 2f, H * 0.45f + 34, 14, 0xFFFFFFFF, Paint.Align.CENTER);
        }
    }

    void txt(Canvas c, String s, float x, float y, float size, int col, Paint.Align al) {
        tp.setTextSize(size);
        tp.setColor(col);
        tp.setTextAlign(al);
        c.drawText(s, x, y, tp);
    }

    void layer(Canvas c, Path pa, int col, float off, float by) {
        float o = -(((off % W) + W) % W);
        p.setColor(col);
        c.save();
        c.translate(o, by);
        c.drawPath(pa, p);
        c.translate(W, 0);
        c.drawPath(pa, p);
        c.restore();
    }

    void drawBg(Canvas c) {
        pSky.setShader(skySh);
        c.drawRect(0, 0, W, H, pSky);
        if (stars.length > 0) {
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(2f);
            c.drawPoints(stars, p);
        }
        if (tr.sun != 0) {
            p.setColor((tr.sun & 0x00FFFFFF) | 0x40000000);
            c.drawCircle(W * 0.72f, H * 0.27f, 44f, p);
            p.setColor(tr.sun);
            c.drawCircle(W * 0.72f, H * 0.27f, 26f, p);
        }
        float by = H * 0.5f + 3f;
        layer(c, bgFar, tr.bgFar, bg1, by);
        layer(c, bgNear, tr.bgNear, bg2, by);
        if (!bgTrees.isEmpty()) layer(c, bgTrees, shade(tr.bgNear, 0.55f), bg2 * 1.3f, by);
        if (!bgX.isEmpty()) layer(c, bgX, tr.night ? 0xFFFFE08A : 0xFFF4F8FB, bg2, by);
        p.setColor(tr.g1);
        c.drawRect(0, by, W, H, p);
    }

    void poly(Canvas c, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int col) {
        path.reset();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.lineTo(x4, y4);
        path.close();
        p.setColor(col);
        c.drawPath(path, p);
    }

    void tri(Canvas c, float x1, float y1, float x2, float y2, float x3, float y3) {
        path.reset();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        c.drawPath(path, p);
    }

    void drawSeg(Canvas c, Seg s) {
        int ci = s.color;
        p.setColor(ci == 0 ? tr.g1 : tr.g2);
        c.drawRect(0, s.sy2, W, s.sy1, p);
        float r1 = s.sw1 / 6f, r2 = s.sw2 / 6f;
        int rm = ci == 0 ? tr.rm1 : tr.rm2;
        poly(c, s.sx1 - s.sw1 - r1, s.sy1, s.sx1 - s.sw1, s.sy1, s.sx2 - s.sw2, s.sy2, s.sx2 - s.sw2 - r2, s.sy2, rm);
        poly(c, s.sx1 + s.sw1 + r1, s.sy1, s.sx1 + s.sw1, s.sy1, s.sx2 + s.sw2, s.sy2, s.sx2 + s.sw2 + r2, s.sy2, rm);
        int rd = s.special == 1 ? 0xFFFFFFFF : (s.special == 2 ? 0xFF111111 : (ci == 0 ? tr.rd1 : tr.rd2));
        poly(c, s.sx1 - s.sw1, s.sy1, s.sx1 + s.sw1, s.sy1, s.sx2 + s.sw2, s.sy2, s.sx2 - s.sw2, s.sy2, rd);
        if (ci == 0 && s.special == 0) {
            float lw1 = s.sw1 * 2f / 3f, lw2 = s.sw2 * 2f / 3f;
            float lx1 = s.sx1 - s.sw1 + lw1, lx2 = s.sx2 - s.sw2 + lw2;
            float m1 = s.sw1 / 32f, m2 = s.sw2 / 32f;
            for (int i = 1; i < 3; i++) {
                poly(c, lx1 - m1 / 2, s.sy1, lx1 + m1 / 2, s.sy1, lx2 + m2 / 2, s.sy2, lx2 - m2 / 2, s.sy2, 0xFFF2EBD3);
                lx1 += lw1;
                lx2 += lw2;
            }
        }
    }

    void drawWorld(Canvas c) {
        Seg base = seg(pos);
        float bp = (pos % SEG) / SEG;
        Seg ps = seg(pos + PZ);
        float pp = ((pos + PZ) % SEG) / SEG;
        float py = ps.y1 + (ps.y2 - ps.y1) * pp;
        float camY = py + CAMH, camX = playerX * ROAD;

        drawBg(c);

        float maxy = H, x = 0, dx = -(base.curve * bp);
        float hw = W * 0.5f, hh = H * 0.5f;
        for (int n = 0; n < DRAW; n++) {
            Seg s = segs[(base.index + n) % N];
            boolean looped = s.index < base.index;
            float cz = pos - (looped ? L : 0f);
            float z1 = s.z1 - cz, z2 = s.z2 - cz;
            s.clip = maxy;
            float cx1 = x - camX, cx2 = x + dx - camX;
            x += dx;
            dx += s.curve;
            if (z1 <= CAMD) {
                s.valid = false;
                continue;
            }
            s.valid = true;
            float sc1 = CAMD / z1, sc2 = CAMD / z2;
            s.sc1 = sc1;
            s.sc2 = sc2;
            s.sx1 = hw + sc1 * cx1 * hw;
            s.sy1 = hh - sc1 * (s.y1 - camY) * hh;
            s.sw1 = sc1 * ROAD * hw;
            s.sx2 = hw + sc2 * cx2 * hw;
            s.sy2 = hh - sc2 * (s.y2 - camY) * hh;
            s.sw2 = sc2 * ROAD * hw;
            if (s.sy2 >= s.sy1 || s.sy2 >= maxy) continue;
            drawSeg(c, s);
            maxy = s.sy1;
        }
        horizon = maxy;

        // décor et voitures, de loin vers près
        for (int n = DRAW - 1; n > 0; n--) {
            Seg s = segs[(base.index + n) % N];
            if (!s.valid) continue;
            if (s.spr != null) {
                for (int i = 0; i < s.spr.size(); i++) {
                    Spr o = s.spr.get(i);
                    float w = s.sc1 * o.ww * hw, h = s.sc1 * o.hh * hw;
                    float sx = s.sx1 + s.sc1 * o.off * ROAD * hw, sy = s.sy1;
                    if (w < 2f || sx + w * 2.5f < 0 || sx - w * 2.5f > W) continue;
                    if (sy - h >= s.clip) continue;
                    if (sy > s.clip) {
                        c.save();
                        c.clipRect(0, 0, W, s.clip);
                        drawSprite(c, o, sx, sy, w, h);
                        c.restore();
                    } else {
                        drawSprite(c, o, sx, sy, w, h);
                    }
                }
            }
            if (s.pk != null) {
                for (int i = 0; i < s.pk.size(); i++) {
                    Pick pk = s.pk.get(i);
                    if (pk.taken) continue;
                    float pw2 = s.sc1 * 520f * hw;
                    float px = s.sx1 + s.sc1 * pk.off * ROAD * hw;
                    float py2 = s.sy1 - pw2 * (0.25f + 0.1f * (float) Math.sin(raceT * 5f + s.index));
                    if (pw2 < 3f || px + pw2 < 0 || px - pw2 > W || py2 > s.clip) continue;
                    drawPick(c, pk.type, px, py2, pw2);
                }
            }
            for (int i = 0; i < s.cars.size(); i++) {
                Car k = s.cars.get(i);
                float kp = (k.z % SEG) / SEG;
                float sc = s.sc1 + (s.sc2 - s.sc1) * kp;
                float cx = s.sx1 + (s.sx2 - s.sx1) * kp + sc * k.off * ROAD * hw;
                float cy = s.sy1 + (s.sy2 - s.sy1) * kp;
                float cw = sc * CARW * ROAD * hw;
                if (cw < 2f || cx + cw < 0 || cx - cw > W) continue;
                float ch = cw * (k.type == 1 ? 1.0f : 0.55f);
                if (cy - ch >= s.clip) continue;
                boolean brk = (k.type == 2 && k.speed < BASE_MAX * 0.5f) || k.type == 3;
                if (cy > s.clip) {
                    c.save();
                    c.clipRect(0, 0, W, s.clip);
                    drawCar(c, cx, cy, cw, k.col, k.colD, k.type, brk, false);
                    c.restore();
                } else {
                    drawCar(c, cx, cy, cw, k.col, k.colD, k.type, brk, false);
                }
            }
        }

        // voiture du joueur
        float pw = CARW * ROAD * (CAMD / PZ) * hw;
        float bounce = speed > 100f ? (rnd.nextFloat() - 0.5f) * 2.2f * (speed / maxSpeed) : 0f;
        float pby = H * 0.97f + bounce;
        drawCar(c, hw + lean * 5f, pby, pw, CARC[selCar], shade(CARC[selCar], 0.65f), 2, brake, nitroT > 0);
        if (shield > 0) {
            p.setColor(((int) (Math.min(1f, shield) * 70f) << 24) | 0x0038B6FF);
            c.drawOval(hw + lean * 5f - pw * 0.7f, pby - pw * 0.9f, hw + lean * 5f + pw * 0.7f, pby + 4f, p);
        }

        // brume d'horizon
        c.save();
        c.translate(0, horizon - hazeH * 0.3f);
        pHaze.setShader(hazeSh);
        c.drawRect(0, 0, W, hazeH, pHaze);
        c.restore();

        // lignes de vitesse (nitro)
        if (nitroT > 0) {
            p.setColor(0x44FFFFFF);
            for (int i = 0; i < 10; i++) {
                float a = rnd.nextFloat() * 6.2832f;
                float r0 = 60 + rnd.nextFloat() * 120, r1 = r0 + 50 + rnd.nextFloat() * 90;
                p.setStrokeWidth(2f);
                c.drawLine(hw + (float) Math.cos(a) * r0 * 2f, hh + (float) Math.sin(a) * r0,
                        hw + (float) Math.cos(a) * r1 * 2f, hh + (float) Math.sin(a) * r1, p);
            }
        }
    }

    void drawSprite(Canvas c, Spr o, float cx, float by, float w, float h) {
        switch (o.type) {
            case 0: { // cactus
                p.setColor(0xFF2E7D32);
                c.drawRect(cx - w * 0.18f, by - h, cx + w * 0.18f, by, p);
                c.drawRect(cx - w * 0.5f, by - h * 0.62f, cx - w * 0.18f, by - h * 0.5f, p);
                c.drawRect(cx - w * 0.5f, by - h * 0.78f, cx - w * 0.34f, by - h * 0.5f, p);
                c.drawRect(cx + w * 0.18f, by - h * 0.5f, cx + w * 0.5f, by - h * 0.38f, p);
                c.drawRect(cx + w * 0.34f, by - h * 0.66f, cx + w * 0.5f, by - h * 0.38f, p);
                p.setColor(0xFF3F9A45);
                c.drawRect(cx - w * 0.08f, by - h, cx + w * 0.02f, by, p);
                break;
            }
            case 1: { // palmier
                p.setColor(0xFF8D6E4C);
                c.drawRect(cx - w * 0.05f, by - h * 0.82f, cx + w * 0.05f, by, p);
                p.setColor(0xFF2E9E4F);
                c.drawOval(cx - w * 0.5f, by - h * 0.95f, cx + w * 0.04f, by - h * 0.8f, p);
                c.drawOval(cx - w * 0.04f, by - h * 0.95f, cx + w * 0.5f, by - h * 0.8f, p);
                p.setColor(0xFF3DBD60);
                c.drawOval(cx - w * 0.3f, by - h, cx + w * 0.3f, by - h * 0.84f, p);
                break;
            }
            case 2: { // sapin
                p.setColor(0xFF5D4037);
                c.drawRect(cx - w * 0.06f, by - h * 0.2f, cx + w * 0.06f, by, p);
                p.setColor(0xFF1F6B3A);
                tri(c, cx - w * 0.5f, by - h * 0.2f, cx + w * 0.5f, by - h * 0.2f, cx, by - h * 0.62f);
                p.setColor(0xFF248045);
                tri(c, cx - w * 0.4f, by - h * 0.45f, cx + w * 0.4f, by - h * 0.45f, cx, by - h * 0.82f);
                p.setColor(0xFF2A9453);
                tri(c, cx - w * 0.28f, by - h * 0.68f, cx + w * 0.28f, by - h * 0.68f, cx, by - h);
                break;
            }
            case 3: { // rocher
                p.setColor(0xFF7A6F66);
                path.reset();
                path.moveTo(cx - w * 0.5f, by);
                path.lineTo(cx - w * 0.35f, by - h * 0.7f);
                path.lineTo(cx - w * 0.05f, by - h);
                path.lineTo(cx + w * 0.3f, by - h * 0.65f);
                path.lineTo(cx + w * 0.5f, by);
                path.close();
                c.drawPath(path, p);
                p.setColor(0xFF978B80);
                tri(c, cx - w * 0.35f, by - h * 0.7f, cx - w * 0.05f, by - h, cx - w * 0.1f, by - h * 0.3f);
                break;
            }
            case 4: { // panneau publicitaire
                p.setColor(0xFF555555);
                c.drawRect(cx - w * 0.3f, by - h * 0.56f, cx - w * 0.24f, by, p);
                c.drawRect(cx + w * 0.24f, by - h * 0.56f, cx + w * 0.3f, by, p);
                p.setColor(0xFF3A3A3A);
                c.drawRect(cx - w * 0.5f, by - h, cx + w * 0.5f, by - h * 0.55f, p);
                p.setColor(o.col);
                c.drawRect(cx - w * 0.46f, by - h * 0.96f, cx + w * 0.46f, by - h * 0.59f, p);
                p.setColor(0xFFFFFFFF);
                c.drawRect(cx - w * 0.36f, by - h * 0.86f, cx + w * 0.36f, by - h * 0.78f, p);
                c.drawRect(cx - w * 0.36f, by - h * 0.72f, cx + w * 0.1f, by - h * 0.66f, p);
                break;
            }
            case 5: { // immeuble
                p.setColor(o.col);
                c.drawRect(cx - w * 0.5f, by - h, cx + w * 0.5f, by, p);
                p.setColor(shade(o.col, 0.76f));
                c.drawRect(cx + w * 0.2f, by - h, cx + w * 0.5f, by, p);
                p.setColor(shade(o.col, 0.6f));
                c.drawRect(cx - w * 0.5f, by - h, cx + w * 0.5f, by - h * 0.97f, p);
                if (w > 12f) {
                    int rows = (int) Math.max(0f, Math.min(12f, h / (w * 0.25f)));
                    float step = h / (rows + 1);
                    p.setColor(tr.night ? 0xFFFFE08A : 0x77DDF3FF);
                    for (int i = 1; i <= rows; i++) {
                        float y0 = by - h + i * step;
                        c.drawRect(cx - w * 0.4f, y0, cx + w * 0.14f, y0 + step * 0.45f, p);
                    }
                }
                break;
            }
            case 6: { // lampadaire
                float dir = o.off > 0 ? -1f : 1f;
                float ex = cx + dir * w * 2.2f;
                p.setColor(0xFF4A4A4A);
                c.drawRect(cx - w * 0.12f, by - h, cx + w * 0.12f, by, p);
                c.drawRect(Math.min(cx, ex), by - h, Math.max(cx, ex), by - h + Math.max(1f, h * 0.03f), p);
                if (tr.night) {
                    p.setColor(0x44FFF2A0);
                    c.drawCircle(ex, by - h, w * 0.9f, p);
                }
                p.setColor(tr.night ? 0xFFFFF2A0 : 0xFFDDDDDD);
                c.drawCircle(ex, by - h, Math.max(1f, w * 0.25f), p);
                break;
            }
            default: { // arbre
                p.setColor(0xFF5D4037);
                c.drawRect(cx - w * 0.07f, by - h * 0.45f, cx + w * 0.07f, by, p);
                p.setColor(0xFF2F8F46);
                c.drawOval(cx - w * 0.5f, by - h, cx + w * 0.5f, by - h * 0.3f, p);
                p.setColor(0xFF3FA95A);
                c.drawOval(cx - w * 0.35f, by - h * 0.95f, cx + w * 0.2f, by - h * 0.55f, p);
                break;
            }
        }
    }

    /** kind : 0 voiture, 1 camion, 2 sportive (aileron). Dessinée de dos, en unités "largeur = 1". */
    void drawCar(Canvas c, float cx, float by, float w, int col, int colD, int kind, boolean brk, boolean flame) {
        if (w < 3f) return;
        if (w < 9f) {
            p.setColor(col);
            c.drawRect(cx - w / 2, by - w * (kind == 1 ? 0.9f : 0.45f), cx + w / 2, by, p);
            p.setColor(0xFFFF3030);
            c.drawRect(cx - w * 0.42f, by - w * 0.3f, cx - w * 0.25f, by - w * 0.2f, p);
            c.drawRect(cx + w * 0.25f, by - w * 0.3f, cx + w * 0.42f, by - w * 0.2f, p);
            return;
        }
        c.save();
        c.translate(cx, by);
        c.scale(w, w);
        p.setColor(0x66000000);
        c.drawOval(-0.56f, -0.05f, 0.56f, 0.07f, p);
        p.setColor(0xFF121212);
        c.drawRect(-0.5f, -0.22f, -0.35f, 0f, p);
        c.drawRect(0.35f, -0.22f, 0.5f, 0f, p);
        if (kind == 1) {
            p.setColor(colD);
            c.drawRect(-0.5f, -1.02f, 0.5f, -0.14f, p);
            p.setColor(col);
            c.drawRect(-0.47f, -0.99f, 0.47f, -0.17f, p);
            p.setColor(colD);
            c.drawRect(-0.01f, -0.99f, 0.01f, -0.17f, p);
            p.setColor(0xFF2A2A2A);
            c.drawRect(-0.4f, -0.22f, 0.4f, -0.12f, p);
        } else {
            p.setColor(colD);
            c.drawRoundRect(-0.5f, -0.36f, 0.5f, -0.06f, 0.07f, 0.07f, p);
            p.setColor(col);
            c.drawRoundRect(-0.5f, -0.38f, 0.5f, -0.15f, 0.07f, 0.07f, p);
            path.reset();
            path.moveTo(-0.37f, -0.36f);
            path.lineTo(-0.27f, -0.54f);
            path.lineTo(0.27f, -0.54f);
            path.lineTo(0.37f, -0.36f);
            path.close();
            c.drawPath(path, p);
            path.reset();
            path.moveTo(-0.31f, -0.37f);
            path.lineTo(-0.24f, -0.5f);
            path.lineTo(0.24f, -0.5f);
            path.lineTo(0.31f, -0.37f);
            path.close();
            p.setColor(0xFF16212B);
            c.drawPath(path, p);
            if (kind == 2) {
                p.setColor(colD);
                for (int i = 0; i < 3; i++) c.drawRect(-0.22f, -0.36f + i * 0.045f, 0.22f, -0.345f + i * 0.045f, p);
            }
            if (kind == 3) {
                boolean ph = ((int) (raceT * 7f) & 1) == 0;
                p.setColor(ph ? 0x44FF2020 : 0x442060FF);
                c.drawRect(-0.42f, -0.74f, 0.42f, -0.5f, p);
                p.setColor(ph ? 0xFFFF2020 : 0xFF2060FF);
                c.drawRect(-0.26f, -0.62f, 0f, -0.54f, p);
                p.setColor(ph ? 0xFF2060FF : 0xFFFF2020);
                c.drawRect(0f, -0.62f, 0.26f, -0.54f, p);
                p.setColor(0xFF1A1A1A);
                c.drawRect(-0.5f, -0.2f, 0.5f, -0.15f, p);
            }
            if (kind == 2) {
                p.setColor(colD);
                c.drawRect(-0.34f, -0.52f, -0.3f, -0.38f, p);
                c.drawRect(0.3f, -0.52f, 0.34f, -0.38f, p);
                c.drawRect(-0.48f, -0.6f, 0.48f, -0.53f, p);
            }
        }
        p.setColor(brk ? 0xFFFF3B30 : 0xFFB3141A);
        c.drawRect(-0.47f, -0.3f, -0.27f, -0.22f, p);
        c.drawRect(0.27f, -0.3f, 0.47f, -0.22f, p);
        if (brk || tr.night) {
            p.setColor(0x55FF2020);
            c.drawRect(-0.55f, -0.36f, -0.2f, -0.16f, p);
            c.drawRect(0.2f, -0.36f, 0.55f, -0.16f, p);
        }
        if (kind == 2) {
            p.setColor(0xFF8A1018);
            c.drawRect(-0.27f, -0.285f, 0.27f, -0.255f, p);
        }
        p.setColor(0xFFF4F4F4);
        c.drawRect(-0.08f, -0.24f, 0.08f, -0.17f, p);
        if (flame) {
            float fl = 0.18f + rnd.nextFloat() * 0.14f;
            p.setColor(0xFFFF8A00);
            tri(c, -0.46f, -0.12f, -0.28f, -0.12f, -0.37f, -0.12f + fl);
            tri(c, 0.28f, -0.12f, 0.46f, -0.12f, 0.37f, -0.12f + fl);
            p.setColor(0xFFFFF07A);
            tri(c, -0.42f, -0.12f, -0.32f, -0.12f, -0.37f, -0.12f + fl * 0.55f);
            tri(c, 0.32f, -0.12f, 0.42f, -0.12f, 0.37f, -0.12f + fl * 0.55f);
        }
        c.restore();
    }

    // ------------------------------------------------------------ HUD
    static String money(int v) {
        String s = Integer.toString(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append(' ');
            b.append(s.charAt(i));
        }
        return (v < 0 ? "-$" : "$") + b;
    }

    static String fmt(float t) {
        int m = (int) (t / 60);
        float s = t - m * 60;
        return String.format(Locale.US, "%d:%04.1f", m, s);
    }

    float frac(float d) {
        return Math.max(0f, Math.min(1f, d / finishDist));
    }

    void panel(Canvas c, float x, float y, float w, float h) {
        p.setColor(0xFFB8732E);
        c.drawRoundRect(x, y, x + w, y + h, 5, 5, p);
        p.setColor(0xFF1E120C);
        c.drawRoundRect(x + 2, y + 2, x + w - 2, y + h - 2, 4, 4, p);
    }

    void bar(Canvas c, float x, float y, float w, float h, float f, int col, int n) {
        float sw = w / n;
        int on = Math.round(Math.max(0f, Math.min(1f, f)) * n);
        for (int i = 0; i < n; i++) {
            p.setColor(i < on ? col : 0xFF3A2A20);
            c.drawRect(x + i * sw, y, x + (i + 1) * sw - 1.5f, y + h, p);
        }
    }

    void drawPick(Canvas c, int type, float cx, float by, float w) {
        float r = w * 0.5f, cy = by - r;
        p.setColor(0x44FFFFFF);
        c.drawCircle(cx, cy, r * 1.15f, p);
        if (type == 2) {
            p.setColor(0xFFC98A00);
            c.drawCircle(cx, cy, r, p);
            p.setColor(0xFFFFD400);
            c.drawCircle(cx, cy, r * 0.8f, p);
            p.setColor(0xFFC98A00);
            c.drawRect(cx - r * 0.12f, cy - r * 0.5f, cx + r * 0.12f, cy + r * 0.5f, p);
        } else if (type == 1) {
            p.setColor(0xFF1B6FB5);
            c.drawCircle(cx, cy, r, p);
            p.setColor(0xFF38B6FF);
            c.drawCircle(cx, cy, r * 0.8f, p);
            p.setColor(0xFFFFFFFF);
            tri(c, cx + r * 0.15f, cy - r * 0.6f, cx - r * 0.35f, cy + r * 0.1f, cx + r * 0.05f, cy + r * 0.1f);
            tri(c, cx - r * 0.15f, cy + r * 0.6f, cx + r * 0.35f, cy - r * 0.1f, cx - r * 0.05f, cy - r * 0.1f);
        } else {
            p.setColor(0xFFE8283C);
            c.drawCircle(cx - r * 0.35f, cy - r * 0.2f, r * 0.45f, p);
            c.drawCircle(cx + r * 0.35f, cy - r * 0.2f, r * 0.45f, p);
            tri(c, cx - r * 0.78f, cy - r * 0.05f, cx + r * 0.78f, cy - r * 0.05f, cx, cy + r * 0.7f);
            p.setColor(0xAAFFFFFF);
            c.drawCircle(cx - r * 0.45f, cy - r * 0.32f, r * 0.12f, p);
        }
    }

    void drawHud(Canvas c) {
        p.setColor(0x22FFFFFF);
        tri(c, 42, H * 0.5f - 26, 42, H * 0.5f + 26, 14, H * 0.5f);
        tri(c, W - 42, H * 0.5f - 26, W - 42, H * 0.5f + 26, W - 14, H * 0.5f);

        panel(c, 4, 3, 64, 42);
        txt(c, "NIV", 36, 16, 11, 0xFFE0A030, Paint.Align.CENTER);
        txt(c, String.valueOf(level()), 36, 40, 24, 0xFFFFFFFF, Paint.Align.CENTER);

        panel(c, 72, 3, 148, 42);
        txt(c, "BOOST", 80, 17, 11, 0xFFE0A030, Paint.Align.LEFT);
        bar(c, 124, 8, 90, 9, nitros / 5f, nitroT > 0 ? 0xFFFF9A20 : 0xFF38B6FF, 5);
        txt(c, "DAMAGE", 80, 37, 11, 0xFFE0A030, Paint.Align.LEFT);
        float hp = 1f - damage / 100f;
        bar(c, 124, 28, 90, 9, hp, hp > 0.5f ? 0xFF5CE08A : (hp > 0.25f ? 0xFFFFA030 : 0xFFFF4040), 12);

        panel(c, 224, 3, 148, 42);
        txt(c, "ARGENT", 230, 17, 11, 0xFFE0A030, Paint.Align.LEFT);
        txt(c, money(cash), 366, 18, 15, 0xFFFFFFFF, Paint.Align.RIGHT);
        txt(c, "DIST.", 230, 37, 11, 0xFFE0A030, Paint.Align.LEFT);
        bar(c, 262, 28, 104, 9, frac(totalDist), 0xFFC8843A, 20);
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            p.setColor(k.col);
            c.drawCircle(262 + 104 * frac(k.dist), 32.5f, 3.5f, p);
        }
        p.setColor(0xFFFFD400);
        c.drawCircle(262 + 104 * frac(totalDist), 32.5f, 4.5f, p);

        panel(c, 376, 3, 120, 42);
        txt(c, "TOUR " + lapNow + "/" + tr.laps, 384, 18, 13, 0xFFFFFFFF, Paint.Align.LEFT);
        txt(c, fmt(raceT), 384, 40, 19, 0xFFFFFFFF, Paint.Align.LEFT);

        panel(c, 500, 3, 66, 42);
        txt(c, "PARI", 533, 17, 11, 0xFFE0A030, Paint.Align.CENTER);
        txt(c, bet > 0 ? money(bet) : "--", 533, 38, 14, bet > 0 ? 0xFFB8F5C0 : 0xFFAAAAAA, Paint.Align.CENTER);

        panel(c, 570, 3, 66, 42);
        txt(c, "POS", 603, 15, 11, 0xFFE0A030, Paint.Align.CENTER);
        txt(c, String.valueOf(curPlace()), 603, 41, 30, 0xFFFFD400, Paint.Align.CENTER);

        txt(c, String.valueOf((int) (speed * 0.02f)), 14, H - 22, 44, 0xFFFFA030, Paint.Align.LEFT);
        txt(c, "KM/H", 16, H - 6, 13, 0xFFE0A030, Paint.Align.LEFT);

        if (flash > 0) c.drawColor(((int) (Math.min(1f, flash * 5f) * 70f) << 24) | 0x00FFFFFF);
        if (msgT > 0 && msg != null) {
            float a = Math.min(1f, msgT / 0.5f);
            txt(c, msg, W / 2f, H * 0.36f - (1.6f - msgT) * 16f, 22, ((int) (a * 255f) << 24) | (msgCol & 0x00FFFFFF), Paint.Align.CENTER);
        }
        if (police != null && state == RACE && policeGap() < 7000f) {
            boolean ph = ((int) (raceT * 6f) & 1) == 0;
            p.setColor(ph ? 0xAAFF2020 : 0xAA2060FF);
            c.drawRect(0, 50, 7, H, p);
            p.setColor(ph ? 0xAA2060FF : 0xAAFF2020);
            c.drawRect(W - 7, 50, W, H, p);
            txt(c, "POLICE !", W / 2f, 72, 22, ph ? 0xFFFF4040 : 0xFF5C90FF, Paint.Align.CENTER);
        }

        if (goT > 0) txt(c, "GO !", W / 2f, H * 0.5f, 80, 0xFF5CE08A, Paint.Align.CENTER);
        if (finished && state == RACE) txt(c, "ARRIVÉE !", W / 2f, H * 0.5f, 56, 0xFFFFD400, Paint.Align.CENTER);
        if (hint > 0 && state != RESULT) {
            txt(c, "Touche gauche / droite = diriger  ·  centre haut = frein  ·  centre bas = nitro",
                    W / 2f, H - 10, 12, 0xCCFFFFFF, Paint.Align.CENTER);
        }
    }

    void drawResult(Canvas c) {
        c.drawColor(0xB0000000);
        c.save();
        c.translate(0, oy);
        txt(c, place == 1 ? "VICTOIRE !" : place + "e place", W / 2f, 64, 44, place == 1 ? 0xFFFFD400 : 0xFFFFFFFF, Paint.Align.CENTER);
        txt(c, "Temps " + fmt(raceT) + (newRecord ? "  ·  NOUVEAU RECORD !" : ""), W / 2f, 88, 14, 0xFFDDDDDD, Paint.Align.CENTER);
        if (bet > 0) {
            if (betWon) txt(c, "Pari gagné  +" + money(profit), 60, 128, 20, 0xFF5CE08A, Paint.Align.LEFT);
            else txt(c, "Pari perdu  -" + money(bet), 60, 128, 20, 0xFFFF6B6B, Paint.Align.LEFT);
        } else {
            txt(c, "Aucun pari", 60, 128, 20, 0xFFBBBBBB, Paint.Align.LEFT);
        }
        txt(c, "Prime  +" + money(prize), 60, 150, 20, 0xFFFFFFFF, Paint.Align.LEFT);
        txt(c, "XP  +" + xpGain, 60, 170, 15, 0xFF7FD0FF, Paint.Align.LEFT);
        if (levelUp) txt(c, "NIVEAU " + level() + " !", 60, 190, 18, 0xFFFFD400, Paint.Align.LEFT);
        txt(c, "Solde  " + money(cash), 60, 214, 22, 0xFFFFD400, Paint.Align.LEFT);
        if (loan) txt(c, "Un sponsor te prête $300", 60, 230, 12, 0xFFDDDDDD, Paint.Align.LEFT);
        for (int i = 0; i < order.size(); i++) {
            Car k = order.get(i);
            txt(c, (i + 1) + ". " + (k == null ? "TOI" : k.name), 380, 120 + i * 22, 17,
                    k == null ? 0xFFFFD400 : 0xFFFFFFFF, Paint.Align.LEFT);
        }
        btn(c, R_REP, "REJOUER", 18, true, true);
        btn(c, R_MEN, "MENU", 18, false, true);
        c.restore();
    }

    // ------------------------------------------------------------ menu : carte des USA
    void btn(Canvas c, int[] r, String label, float size, boolean on, boolean enabled) {
        p.setColor(on ? 0xFFC89B00 : 0xFF8A5524);
        c.drawRoundRect(r[0], r[1], r[0] + r[2], r[1] + r[3], 6, 6, p);
        p.setColor(on ? 0xFFFFD400 : (enabled ? 0xFF2A1810 : 0xFF1A1210));
        c.drawRoundRect(r[0] + 2, r[1] + 2, r[0] + r[2] - 2, r[1] + r[3] - 2, 5, 5, p);
        txt(c, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f + size * 0.35f, size,
                on ? 0xFF111111 : (enabled ? 0xFFFFFFFF : 0x77FFFFFF), Paint.Align.CENTER);
    }

    void arrow(Canvas c, int[] r, boolean toLeft) {
        btn(c, r, "", 12, false, true);
        p.setColor(0xFFFFD400);
        float cx = r[0] + r[2] / 2f, cy = r[1] + r[3] / 2f;
        if (toLeft) tri(c, cx + 7, cy - 11, cx + 7, cy + 11, cx - 8, cy);
        else tri(c, cx - 7, cy - 11, cx - 7, cy + 11, cx + 8, cy);
    }

    void drawMenu(Canvas c) {
        c.save();
        c.translate(0, oy);
        int n = Tr.ALL.length;
        boolean un = unlocked(selTrack);

        txt(c, "LAMBO 2.0", 10, 24, 24, 0xFFFFD400, Paint.Align.LEFT);
        panel(c, R_LV[0], R_LV[1], R_LV[2], R_LV[3]);
        p.setColor(0xFFE0A030);
        c.drawRect(R_LV[0] + 3, R_LV[1] + R_LV[3] - 6, R_LV[0] + 3 + (R_LV[2] - 6) * lvFrac(), R_LV[1] + R_LV[3] - 3, p);
        txt(c, "NIV " + level(), R_LV[0] + R_LV[2] / 2f, R_LV[1] + 12, 11, 0xFFFFFFFF, Paint.Align.CENTER);
        btn(c, R_GAR, "GARAGE", 13, false, true);
        txt(c, money(cash), 630, 22, 20, 0xFF5CE08A, Paint.Align.RIGHT);

        // carte
        panel(c, 8, 34, 300, 246);
        path.reset();
        for (int i = 0; i < US.length; i += 2) {
            float x = MAPX + US[i] * MAPW, y = MAPY + US[i + 1] * MAPH;
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
        p.setColor(0xFF1F2E26);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(0xFF5A7A64);
        c.drawPath(path, p);
        p.setColor(0x66FFD400);
        for (int i = 0; i < n - 1; i++) {
            c.drawLine(MAPX + TPOS[i][0] * MAPW, MAPY + TPOS[i][1] * MAPH,
                    MAPX + TPOS[i + 1][0] * MAPW, MAPY + TPOS[i + 1][1] * MAPH, p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < n; i++) {
            float x = MAPX + TPOS[i][0] * MAPW, y = MAPY + TPOS[i][1] * MAPH;
            boolean u = unlocked(i);
            p.setColor(u ? (pod[i] ? 0xFF5CE08A : 0xFFFFD400) : 0xFF777777);
            c.drawCircle(x, y, 7, p);
            if (!u) {
                p.setColor(0xFF222222);
                c.drawRect(x - 3, y - 1, x + 3, y + 4, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.5f);
                c.drawArc(x - 2.5f, y - 5, x + 2.5f, y + 1, 180, 180, false, p);
                p.setStyle(Paint.Style.FILL);
            }
            if (i == selTrack) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f);
                p.setColor(0xFFFFFFFF);
                c.drawCircle(x, y, 11f + (float) Math.sin(bg1 * 0.8f) * 1.5f, p);
                p.setStyle(Paint.Style.FILL);
            }
            txt(c, ST[i], x, y + 20, 10, 0xFFDDDDDD, Paint.Align.CENTER);
        }
        arrow(c, R_TPREV, true);
        arrow(c, R_TNEXT, false);
        txt(c, (selTrack + 1) + " / " + n, 158, 267, 14, 0xFFFFFFFF, Paint.Align.CENTER);

        // aperçu de la course
        panel(c, 316, 34, 316, 246);
        txt(c, tr.name, 326, 58, 22, 0xFFFFFFFF, Paint.Align.LEFT);
        txt(c, tr.state + " · " + tr.laps + " tours", 326, 76, 13, 0xFFCCCCCC, Paint.Align.LEFT);
        p.setColor(0xFF140C08);
        c.drawRect(324, 84, 464, 160, p);
        if (prev.length > 3) {
            float sc = Math.min(124f / prevW, 60f / prevH);
            float ox = 324 + (140 - prevW * sc) / 2f, oy2 = 84 + (76 - prevH * sc) / 2f;
            path.reset();
            for (int i = 0; i < prev.length; i += 2) {
                float x = ox + prev[i] * sc, y = oy2 + prev[i + 1] * sc;
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.5f);
            p.setColor(0xFFFFD400);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF5CE08A);
            c.drawCircle(ox + prev[0] * sc, oy2 + prev[1] * sc, 4, p);
        }
        int dif = 1 + (selTrack * 4) / 7;
        txt(c, "DIFFICULTÉ", 474, 96, 11, 0xFFE0A030, Paint.Align.LEFT);
        for (int i = 0; i < 5; i++) {
            p.setColor(i < dif ? 0xFFFF6B3D : 0x44FFFFFF);
            c.drawCircle(480 + i * 15, 106, 5, p);
        }
        txt(c, "PRIME  " + money((int) (PRIZE[0] * (1f + selTrack * 0.4f))), 474, 128, 13, 0xFFFFFFFF, Paint.Align.LEFT);
        txt(c, "NIVEAU REQUIS  " + REQ[selTrack], 474, 146, 12, level() >= REQ[selTrack] ? 0xFF5CE08A : 0xFFFF6B6B, Paint.Align.LEFT);
        txt(c, "RECORD  " + (best[selTrack] > 0 ? fmt(best[selTrack]) : "--"), 474, 164, 12, 0xFFDDDDDD, Paint.Align.LEFT);
        String cond;
        if (un) {
            cond = pod[selTrack] ? "Podium réussi" : "Course débloquée : vise le podium !";
        } else {
            cond = "VERROUILLÉ : ";
            if (level() < REQ[selTrack]) cond += "niveau " + REQ[selTrack];
            if (selTrack > 0 && !pod[selTrack - 1]) {
                if (level() < REQ[selTrack]) cond += " + ";
                cond += "podium à " + Tr.ALL[selTrack - 1].name;
            }
        }
        txt(c, cond, 326, 178, 11, un ? 0xFF5CE08A : 0xFFFF6B6B, Paint.Align.LEFT);

        btn(c, R_MODE, "PARI : " + (betMode == 0 ? "DUEL " + tr.boss + " ×2" : (betMode == 1 ? "TOP 3 ×1,5" : "VICTOIRE ×3,5")), 12, false, true);
        btn(c, R_BM, "-", 22, false, betIdx > 0);
        btn(c, R_BOX, BETS[betIdx] == 0 ? "SANS PARI" : money(BETS[betIdx]), 14, false, true);
        btn(c, R_BP, "+", 22, false, betIdx < BETS.length - 1 && BETS[betIdx + 1] <= cash);
        btn(c, R_GO, un ? "COURSE !" : "VERROUILLÉE", 20, un, un);
        c.restore();
    }

    void drawGarage(Canvas c) {
        c.save();
        c.translate(0, oy);
        btn(c, R_BACK, "RETOUR", 13, false, true);
        txt(c, "GARAGE", 320, 24, 24, 0xFFFFD400, Paint.Align.CENTER);
        txt(c, money(cash), 630, 22, 20, 0xFF5CE08A, Paint.Align.RIGHT);

        panel(c, 8, 34, 236, 206);
        int vc = viewCar;
        txt(c, CARN[vc], 126, 62, 22, 0xFFFFFFFF, Paint.Align.CENTER);
        drawCar(c, 126, 160, 150, CARC[vc], shade(CARC[vc], 0.65f), 2, false, false);
        txt(c, vc == 0 ? "Voiture de départ" : "+" + Math.round((CARS[vc] - 1f) * 100f) + "% vitesse", 126, 200, 13, 0xFFDDDDDD, Paint.Align.CENTER);
        if (level() < CARL[vc]) txt(c, "Niveau " + CARL[vc] + " requis", 126, 222, 13, 0xFFFF6B6B, Paint.Align.CENTER);
        arrow(c, R_CPREV, true);
        arrow(c, R_CNEXT, false);
        boolean ok = level() >= CARL[vc];
        btn(c, R_CUSE, selCar == vc ? "EN SERVICE" : (ok ? "UTILISER" : "NIV. " + CARL[vc]), 14, selCar == vc, ok);

        for (int i = 0; i < 4; i++) {
            float y0 = 40 + i * 50;
            panel(c, 252, y0, 380, 44);
            txt(c, UPN[i], 262, y0 + 20, 16, 0xFFFFFFFF, Paint.Align.LEFT);
            txt(c, UPD[i], 262, y0 + 37, 11, 0xFFBBBBBB, Paint.Align.LEFT);
            int lv = upLv(i);
            for (int j = 0; j < 5; j++) {
                p.setColor(j < lv ? 0xFFFFD400 : 0xFF3A2A20);
                c.drawRect(400 + j * 26, y0 + 12, 400 + j * 26 + 22, y0 + 24, p);
            }
            boolean can = lv < 5 && cash >= cost(lv);
            btn(c, R_UP[i], lv >= 5 ? "MAX" : money(cost(lv)), 13, false, can);
        }
        txt(c, "Les améliorations valent pour toutes les voitures.", 262, 266, 11, 0xFFAAAAAA, Paint.Align.LEFT);
        c.restore();
    }

    // ------------------------------------------------------------ audio (moteur synthétique, ~0 Ko)
    void initAudio() {
        try {
            int period = 200, reps = 8, n = period * reps;
            short[] buf = new short[n];
            for (int i = 0; i < n; i++) {
                double ph = 2 * Math.PI * (i % period) / period;
                double v = Math.sin(ph) + 0.55 * Math.sin(2 * ph + 0.6) + 0.35 * Math.sin(3 * ph + 1.1) + 0.22 * Math.sin(5 * ph);
                double m = 1 + 0.18 * Math.sin(2 * Math.PI * i / n * 3);
                buf[i] = (short) (v * m * 5200);
            }
            at = new AudioTrack(AudioManager.STREAM_MUSIC, AT_SR, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC);
            at.write(buf, 0, n);
            at.setLoopPoints(0, n, -1);
            at.setVolume(0f);
            at.play();
        } catch (Throwable t) {
            at = null;
        }
        try {
            int n2 = AT_SR * 4 / 5;
            short[] sb = new short[n2];
            for (int i = 0; i < n2; i++) {
                double f = i < n2 / 2 ? 760.0 : 1010.0;
                sb[i] = (short) (Math.sin(2 * Math.PI * f * i / AT_SR) * 3500);
            }
            sir = new AudioTrack(AudioManager.STREAM_MUSIC, AT_SR, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, n2 * 2, AudioTrack.MODE_STATIC);
            sir.write(sb, 0, n2);
            sir.setLoopPoints(0, n2, -1);
            sir.setVolume(0f);
            sir.play();
        } catch (Throwable t) {
            sir = null;
        }
    }

    void stopAudio() {
        try {
            if (at != null) {
                at.stop();
                at.release();
            }
        } catch (Throwable t) {
            // ignore
        }
        at = null;
        try {
            if (sir != null) {
                sir.stop();
                sir.release();
            }
        } catch (Throwable t) {
            // ignore
        }
        sir = null;
    }

    void audio() {
        if (at == null) return;
        try {
            boolean on = (state == RACE || state == CD) && !paused;
            float pct = maxSpeed > 0 ? Math.min(1.4f, speed / maxSpeed) : 0f;
            at.setVolume(on ? 0.12f + 0.2f * Math.min(1f, pct) : 0f);
            float rate = Math.min(2f, 0.7f + 1.2f * pct);
            at.setPlaybackRate((int) (AT_SR * rate));
            if (sir != null) {
                float sv = 0f;
                if (on && police != null) sv = Math.max(0f, 0.3f * (1f - Math.abs(policeGap()) / 9000f));
                sir.setVolume(sv);
            }
        } catch (Throwable t) {
            // ignore
        }
    }
}
