package com.anais.lambo2;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.Random;

/**
 * Lambo 2.0 - course arcade pseudo-3D en vrai pixel art.
 * Le jeu est dessiné dans un framebuffer de 180 px de haut, puis agrandi sans lissage.
 */
public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    // ------------------------------------------------------------ constantes
    static final int SEG = 200, ROAD = 2000, DRAW = 85, LINE_IDX = 24;
    static final float CAMH = 1000f, CAMD = 0.8391f, PZ = CAMH * CAMD;
    static final float CARW = 0.22f, BASE_MAX = 12000f;
    static final int MENU = 0, CD = 1, RACE = 2, RESULT = 3, GARAGE = 4, PREP = 5, TITLE = 6, CHAR = 7;
    static final int[] BETS = {0, 100, 250, 500, 1000, 2500, 5000, 10000};
    static final float[] MODE_PROFIT = {1f, 0.5f, 2.5f};
    static final int[] PRIZE = {1000, 500, 250, 100, 0};
    static final int[] XPP = {120, 80, 55, 30, 15};
    static final String[] NAMES = {"Ace", "Lola", "Mad Max", "Sheriff", "Duke", "Nina", "Slick", "Bandit"};
    static final int[] REQ = {1, 2, 4, 6, 9, 12, 16, 20};
    static final boolean[] POLICE = {false, false, true, true, false, true, true, true};
    static final String[] ST = {"AZ", "TX", "FL", "CA", "CO", "IL", "NV", "NY"};
    static final String[] CARN = {"FURIA", "CORSA", "BLANCA", "AZZURRA"};
    static final int[] CARL = {1, 5, 10, 15};
    static final float[] CARS = {1.00f, 1.04f, 1.08f, 1.12f};
    static final String[] UPN = {"MOTEUR", "PNEUS", "FREINS", "NITRO"};
    static final String[] UPD = {"Vitesse maximale", "Tenue de route", "Freinage", "Duree + puissance"};
    static final String[] TMPN = {"NITRO +2", "PNEUS SLICK", "BLINDAGE", "TURBO"};
    static final String[] TMPD = {"2 charges", "Tenue +2", "Dmg -60%", "Vit. +6%"};
    static final int[] TMPC = {300, 300, 300, 400};
    static final float[] UNIT = {11f, 11f, 11f, 11f, 11f, 15f, 11f, 11f};
    static final int MAPDY = 0;
    static final String[] CHN = {"KADE", "NINA", "REX", "TARA", "DUSTY JACK", "BIG TEX", "MIAMI MIKE", "CALI KATE",
            "ROCKY", "WINDY JOE", "VEGAS VINCE", "BROOKLYN TONY"};
    static final String[] PERK = {"VITESSE MAX +3%", "TENUE DE ROUTE +10%", "DEGATS -25%", "NITRO +1 CHARGE"};
    static final String[] DIFF = {"DEBUTANT", "DEBUTANT", "AMATEUR", "AMATEUR", "PRO", "PRO", "EXPERT", "EXPERT"};
    static final int[] LMI = {0, 0, 2, 2, 3, 1, 4, 1};
    static int fee(int t) {
        return 100 * (t + 1);
    }

    static final int GOLD = 0xFFE0A030, WHITE = 0xFFFFFFFF, ORANGE = 0xFFFFA030, GREEN = 0xFF5CE08A, RED = 0xFFFF6B6B;

    // ------------------------------------------------------------ types
    static final class Spr {
        int type, var;
        float off, ww;
    }

    static final class Pick {
        int type;
        float off;
        boolean taken;
    }

    static final class Car {
        float off, z, speed, dist, finT, skill;
        int type, idx, ch;
        boolean fin;
        String name;
    }

    static final class Seg {
        int index, color, special;
        float z1, z2, y1, y2, curve;
        float sx1, sy1, sw1, sc1, sx2, sy2, sw2, sc2, clip;
        boolean valid;
        final ArrayList<Car> cars = new ArrayList<Car>(2);
        ArrayList<Spr> spr;
        ArrayList<Pick> pk;
    }

    // ------------------------------------------------------------ champs
    final Object lock = new Object();
    Thread th;
    volatile boolean running;
    boolean hw = true;
    final Gfx g;
    final Paint pBlit = new Paint();
    final Rect dst = new Rect();
    int W = 320, H = 180, tick;
    final Random rnd = new Random();
    final SharedPreferences prefs;

    // sauvegarde
    int cash = 2000, eng = 0, tire = 0, upBrk = 0, upNit = 0, selTrack = 0, betIdx = 3, betMode = 0;
    int xp = 0, selCar = 0, viewCar = 0;
    final float[] best = new float[Tr.ALL.length];
    final boolean[] pod = new boolean[Tr.ALL.length];
    final boolean[] tmp = new boolean[4];

    // thème / piste
    Tr tr;
    float bg1, bg2, horizon;
    Seg[] segs;
    int N;
    float L;
    ArrayList<Seg> bl;
    float bY;
    final ArrayList<Car> cars = new ArrayList<Car>();
    final ArrayList<Car> rivals = new ArrayList<Car>();
    float[] prev = new float[0];
    float prevW = 1f, prevH = 1f;

    // état de jeu
    int state = MENU;
    boolean paused;
    float pos, totalDist, speed, playerX, maxSpeed, steer, cent, offLim, finishDist, lineOff;
    float raceT, cd, goT, nitroT, shake, lean, finT, hint, resT, policeT, damage, shield, msgT, flash;
    float brakeF = 1f, nitroDur = 2.2f, nitroPow = 1f, dmgMul = 1f;
    int nitros, bet, place, lapNow, prize, profit, xpGain, picks, fines, msgCol, tmpPaid;
    boolean finished, betWon, loan, newRecord, levelUp;
    String msg, capt = "";
    Car police;
    int selPilot = 0, viewPilot = 0;
    boolean pilotSet, detail;
    float bossT;
    final boolean[] tmpOn = new boolean[4];
    final int[][] rPort = new int[4][4];
    int[] rOk = new int[4], rPilot = new int[4], rDPanel = new int[4], rDX = new int[4], rDGo = new int[4];
    ArrayList<Car> order = new ArrayList<Car>();

    // entrées
    volatile boolean left, right, brake, nitroReq;
    boolean nitroPrev;

    // zones tactiles (recalculées selon la largeur)
    int[] rGarage = new int[4], rNext = new int[4], rBack = new int[4], rGo = new int[4];
    final int[][] rMode = new int[3][4], rTmp = new int[4][4], rUp = new int[4][4];
    int[] rBM = new int[4], rBP = new int[4], rBox = new int[4];
    int[] rGB = new int[4], rCprev = new int[4], rCuse = new int[4], rCnext = new int[4], rRep = new int[4], rMen = new int[4];

    // audio
    AudioTrack at, sir;
    static final int AT_SR = 22050;

    // ------------------------------------------------------------ construction
    public GameView(Context ctx) {
        super(ctx);
        getHolder().addCallback(this);
        setFocusable(true);
        g = new Gfx(ctx.getResources());
        pBlit.setFilterBitmap(false);
        pBlit.setDither(false);
        prefs = ctx.getSharedPreferences("lambo2", Context.MODE_PRIVATE);
        cash = prefs.getInt("cash", 2000);
        eng = prefs.getInt("eng", 0);
        tire = prefs.getInt("tire", 0);
        upBrk = prefs.getInt("brk", 0);
        upNit = prefs.getInt("nit", 0);
        xp = prefs.getInt("xp", 0);
        selCar = Math.max(0, Math.min(3, prefs.getInt("car", 0)));
        selTrack = Math.max(0, Math.min(Tr.ALL.length - 1, prefs.getInt("trk", 0)));
        betIdx = Math.max(0, Math.min(BETS.length - 1, prefs.getInt("bet", 3)));
        betMode = Math.max(0, Math.min(2, prefs.getInt("mode", 0)));
        for (int i = 0; i < best.length; i++) {
            best[i] = prefs.getFloat("b" + i, 0f);
            pod[i] = prefs.getBoolean("p" + i, false);
        }
        if (level() < CARL[selCar]) selCar = 0;
        viewCar = selCar;
        selPilot = Math.max(0, Math.min(3, prefs.getInt("pilot", 0)));
        pilotSet = prefs.getBoolean("pset", false);
        viewPilot = selPilot;
        tr = Tr.ALL[selTrack];
        state = TITLE;
    }

    void saveAll() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("cash", cash).putInt("eng", eng).putInt("tire", tire).putInt("brk", upBrk).putInt("nit", upNit)
                .putInt("pilot", selPilot).putBoolean("pset", pilotSet).putInt("xp", xp).putInt("car", selCar).putInt("trk", selTrack).putInt("bet", betIdx).putInt("mode", betMode);
        for (int i = 0; i < best.length; i++) {
            e.putFloat("b" + i, best[i]);
            e.putBoolean("p" + i, pod[i]);
        }
        e.apply();
    }

    // ------------------------------------------------------------ cycle de vie
    @Override
    public void surfaceCreated(SurfaceHolder h) {
        running = true;
        th = new Thread(this, "game");
        th.start();
        initAudio();
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        running = false;
        try {
            if (th != null) th.join();
        } catch (InterruptedException e) {
            // ignore
        }
        th = null;
        stopAudio();
        pauseGame();
    }

    void pauseGame() {
        synchronized (lock) {
            if (state == RACE || state == CD) paused = true;
        }
    }

    boolean onBack() {
        synchronized (lock) {
            if (state == TITLE) return false;
            if (state == MENU) {
                if (detail) {
                    detail = false;
                    return true;
                }
                state = TITLE;
                return true;
            }
            if (state == CHAR) {
                state = pilotSet ? MENU : TITLE;
                return true;
            }
            if (state == GARAGE || state == PREP || state == RESULT) {
                state = MENU;
                return true;
            }
            if (!paused) {
                paused = true;
                return true;
            }
            if (bet > 0 && !finished) {
                cash -= bet;
                if (cash < 100) cash = 300;
                saveAll();
            }
            paused = false;
            state = MENU;
            return true;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        synchronized (lock) {
            H = 180;
            W = Math.max(320, Math.min(440, Math.round(180f * w / h)));
            g.size(W, H);
            layout();
        }
    }

    void setR(int[] r, int x, int y, int w, int h) {
        r[0] = x;
        r[1] = y;
        r[2] = w;
        r[3] = h;
    }

    void layout() {
        int k = W >= 360 ? 2 : 1;
        int pwid = 44 * k, gapP = (W - 4 * pwid) / 5;
        int y0 = k == 2 ? 24 : 40;
        for (int i = 0; i < 4; i++) setR(rPort[i], gapP + i * (pwid + gapP), y0, pwid, 48 * k);
        int infoY = y0 + 48 * k + 4, infoH = H - infoY - 4;
        setR(rOk, W - 100, infoY + infoH - 26, 92, 22);
        // carte
        setR(rPilot, 2, 2, 44, 48);
        setR(rGarage, 164, 3, 64, 22);
        int dpw = Math.min(W - 8, 300);
        setR(rDPanel, (W - dpw) / 2, 8, dpw, 164);
        setR(rDX, rDPanel[0] + 12, rDPanel[1] + 138, 84, 22);
        setR(rDGo, rDPanel[0] + dpw - 12 - 110, rDPanel[1] + 138, 110, 22);
        // paris
        int mw = Math.round(W * 0.28f);
        for (int i = 0; i < 3; i++) setR(rMode[i], 2, 116 + i * 15, mw, 14);
        int bx0 = 2 + mw + 4;
        int btnW = Math.round(W * 0.27f);
        setR(rBM, bx0, 116, 16, 16);
        setR(rBox, bx0 + 18, 116, 56, 16);
        setR(rBP, bx0 + 76, 116, 16, 16);
        int cw = (W - bx0 - 4 - btnW - 4 - 6) / 4;
        for (int i = 0; i < 4; i++) setR(rTmp[i], bx0 + i * (cw + 2), 136, cw, 30);
        setR(rBack, W - btnW - 2, 116, btnW, 22);
        setR(rGo, W - btnW - 2, 142, btnW, 34);
        // garage
        setR(rGB, 4, 4, 56, 20);
        setR(rCprev, 8, H - 30, 22, 22);
        setR(rCuse, 34, H - 30, 92, 22);
        setR(rCnext, 130, H - 30, 22, 22);
        int gx = 158, gw = W - gx - 4, rh = (H - 40) / 4;
        for (int i = 0; i < 4; i++) setR(rUp[i], gx + gw - 56, 32 + i * rh + (rh - 22) / 2, 52, 22);
        // podium
        setR(rRep, W - 68, 140, 64, 18);
        setR(rMen, W - 68, 160, 64, 18);
    }

    @Override
    public void run() {
        long last = System.nanoTime();
        int frame = 0;
        while (running) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            SurfaceHolder h = getHolder();
            Canvas c = null;
            try {
                if (hw && Build.VERSION.SDK_INT >= 26) {
                    try {
                        c = h.lockHardwareCanvas();
                    } catch (Throwable t) {
                        hw = false;
                        c = null;
                    }
                }
                if (c == null) c = h.lockCanvas();
                if (c != null && g.fb != null) {
                    synchronized (lock) {
                        update(dt);
                        renderFrame();
                        if ((++frame & 3) == 0) audio();
                        dst.set(0, 0, c.getWidth(), c.getHeight());
                        c.drawBitmap(g.fb, null, dst, pBlit);
                    }
                }
            } catch (Exception e) {
                // image ratée : on continue
            } finally {
                if (c != null) {
                    try {
                        h.unlockCanvasAndPost(c);
                    } catch (Exception e) {
                        // ignore
                    }
                }
            }
            long ms = (System.nanoTime() - now) / 1000000L;
            if (ms < 16) {
                try {
                    Thread.sleep(16 - ms);
                } catch (InterruptedException e) {
                    // ignore
                }
            }
        }
    }

    // ------------------------------------------------------------ entrées
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        int idx = e.getActionIndex();
        float vw = Math.max(1, getWidth()), vh = Math.max(1, getHeight());
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            float tx = e.getX(idx) * W / vw, ty = e.getY(idx) * H / vh;
            synchronized (lock) {
                onTap(tx, ty);
            }
        }
        boolean l = false, r = false, b = false, n = false;
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            int up = act == MotionEvent.ACTION_POINTER_UP ? idx : -1;
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == up) continue;
                float fx = e.getX(i) / vw, fy = e.getY(i) / vh;
                if (fx < 0.34f) l = true;
                else if (fx > 0.66f) r = true;
                else if (fy > 0.5f) n = true;
                else b = true;
            }
        }
        left = l;
        right = r;
        brake = b;
        if (n && !nitroPrev) nitroReq = true;
        nitroPrev = n;
        return true;
    }

    static boolean hit(int[] r, float x, float y) {
        return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
    }

    void onTap(float x, float y) {
        if (paused) {
            paused = false;
            return;
        }
        switch (state) {
            case TITLE:
                viewPilot = selPilot;
                state = pilotSet ? MENU : CHAR;
                break;
            case CHAR:
                tapChar(x, y);
                break;
            case MENU:
                tapMenu(x, y);
                break;
            case PREP:
                tapBet(x, y);
                break;
            case GARAGE:
                tapGarage(x, y);
                break;
            case RESULT:
                if (resT > 0.6f) tapResult(x, y);
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------ progression
    static int cost(int level) {
        return 1500 * (level + 1);
    }

    static int need(int lv) {
        return 80 + 20 * lv;
    }

    int level() {
        int lv = 1, rem = xp;
        while (lv < 30 && rem >= need(lv)) {
            rem -= need(lv);
            lv++;
        }
        return lv;
    }

    float lvFrac() {
        int lv = 1, rem = xp;
        while (lv < 30 && rem >= need(lv)) {
            rem -= need(lv);
            lv++;
        }
        return lv >= 30 ? 1f : rem / (float) need(lv);
    }

    boolean unlocked(int i) {
        return level() >= REQ[i] && (i == 0 || pod[i - 1]);
    }

    int upLv(int i) {
        return i == 0 ? eng : (i == 1 ? tire : (i == 2 ? upBrk : upNit));
    }

    void buyUp(int i) {
        int l = upLv(i);
        if (l >= 5 || cash < cost(l)) return;
        cash -= cost(l);
        if (i == 0) eng++;
        else if (i == 1) tire++;
        else if (i == 2) upBrk++;
        else upNit++;
        saveAll();
    }

    int tmpTotal() {
        int t = 0;
        for (int i = 0; i < 4; i++) if (tmp[i]) t += TMPC[i];
        return t;
    }

    void selectTrack(int i) {
        selTrack = i;
        tr = Tr.ALL[i];
        saveAll();
    }

    /** Petit tracé du circuit (intégration des virages) pour l'aperçu. */
    void buildPreview() {
        buildTrack();
        int step = 6, m = N / step;
        prev = new float[m * 2];
        float ang = 0, x = 0, y = 0;
        float minX = 1e9f, maxX = -1e9f, minY = 1e9f, maxY = -1e9f;
        for (int i = 0; i < m; i++) {
            float cv = 0;
            for (int j = 0; j < step; j++) cv += segs[i * step + j].curve;
            ang += cv * 0.014f;
            x += (float) Math.cos(ang);
            y += (float) Math.sin(ang);
            prev[i * 2] = x;
            prev[i * 2 + 1] = y;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        float sc = Math.max(1f, Math.max(maxX - minX, maxY - minY));
        for (int i = 0; i < m; i++) {
            prev[i * 2] = (prev[i * 2] - minX) / sc;
            prev[i * 2 + 1] = (prev[i * 2 + 1] - minY) / sc;
        }
        prevW = Math.max(0.05f, (maxX - minX) / sc);
        prevH = Math.max(0.05f, (maxY - minY) / sc);
    }

    // ------------------------------------------------------------ écrans : touches
    void tapChar(float x, float y) {
        for (int i = 0; i < 4; i++) {
            if (hit(rPort[i], x, y)) {
                viewPilot = i;
                return;
            }
        }
        if (hit(rOk, x, y)) {
            selPilot = viewPilot;
            pilotSet = true;
            saveAll();
            state = MENU;
        }
    }

    void tapMenu(float x, float y) {
        if (detail) {
            if (hit(rDGo, x, y)) {
                if (unlocked(selTrack)) {
                    for (int i = 0; i < 4; i++) tmp[i] = false;
                    capt = "TOUCHE UN BONUS POUR L'ACTIVER";
                    detail = false;
                    clampBet();
                    state = PREP;
                }
            } else if (hit(rDX, x, y) || !hit(rDPanel, x, y)) {
                detail = false;
            }
            return;
        }
        if (hit(rPilot, x, y)) {
            viewPilot = selPilot;
            state = CHAR;
            return;
        }
        if (hit(rGarage, x, y)) {
            viewCar = selCar;
            state = GARAGE;
            return;
        }
        int bi = -1;
        float bd = 16f;
        float ox = (W - 440) / 2f;
        for (int i = 0; i < Atlas.MAP_PTS.length; i++) {
            float dx = x - (Atlas.MAP_PTS[i][0] + ox), dy = y - (Atlas.MAP_PTS[i][1] + MAPDY);
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < bd) {
                bd = d;
                bi = i;
            }
        }
        if (bi >= 0) {
            selectTrack(bi);
            detail = true;
        }
    }

    void clampBet() {
        while (betIdx > 0 && BETS[betIdx] > cash - tmpTotal() - fee(selTrack)) betIdx--;
    }

    void tapBet(float x, float y) {
        if (hit(rBack, x, y)) {
            state = MENU;
            return;
        }
        for (int i = 0; i < 3; i++) {
            if (hit(rMode[i], x, y)) {
                betMode = i;
                saveAll();
                return;
            }
        }
        for (int i = 0; i < 4; i++) {
            if (hit(rTmp[i], x, y)) {
                capt = TMPN[i] + " : " + TMPD[i];
                if (tmp[i]) tmp[i] = false;
                else if (cash - tmpTotal() - fee(selTrack) >= TMPC[i]) tmp[i] = true;
                clampBet();
                return;
            }
        }
        if (hit(rBM, x, y)) {
            if (betIdx > 0) betIdx--;
        } else if (hit(rBP, x, y)) {
            if (betIdx < BETS.length - 1 && BETS[betIdx + 1] <= cash - tmpTotal() - fee(selTrack)) betIdx++;
        } else if (hit(rGo, x, y)) {
            if (cash >= fee(selTrack) + tmpTotal()) startRace();
        }
    }

    void tapGarage(float x, float y) {
        if (hit(rGB, x, y)) {
            state = MENU;
            return;
        }
        if (hit(rCprev, x, y)) viewCar = (viewCar + 3) % 4;
        else if (hit(rCnext, x, y)) viewCar = (viewCar + 1) % 4;
        else if (hit(rCuse, x, y)) {
            if (level() >= CARL[viewCar]) {
                selCar = viewCar;
                saveAll();
            }
        } else {
            for (int i = 0; i < 4; i++) if (hit(rUp[i], x, y)) buyUp(i);
        }
    }

    void tapResult(float x, float y) {
        if (hit(rRep, x, y)) {
            for (int i = 0; i < 4; i++) tmp[i] = false;
            startRace();
        } else if (hit(rMen, x, y)) state = MENU;
    }

    // ------------------------------------------------------------ génération de piste
    static float ein(float a, float b, float q) {
        return a + (b - a) * q * q;
    }

    static float eio(float a, float b, float q) {
        return a + (b - a) * ((float) (-Math.cos(q * Math.PI) / 2) + 0.5f);
    }

    void addSeg(float curve, float y) {
        Seg s = new Seg();
        int n = bl.size();
        s.index = n;
        s.z1 = n * (float) SEG;
        s.z2 = (n + 1) * (float) SEG;
        s.y1 = bY;
        s.y2 = y;
        s.curve = curve;
        s.color = (n / 3) % 2;
        bl.add(s);
        bY = y;
    }

    void addRoad(int en, int ho, int le, float curve, float y) {
        float sy = bY, ey = sy + y * SEG;
        float tot = en + ho + le;
        for (int i = 0; i < en; i++) addSeg(ein(0, curve, i / (float) en), eio(sy, ey, i / tot));
        for (int i = 0; i < ho; i++) addSeg(curve, eio(sy, ey, (en + i) / tot));
        for (int i = 0; i < le; i++) addSeg(eio(curve, 0, i / (float) le), eio(sy, ey, (en + ho + i) / tot));
    }

    int[] sprOf(Spr o) {
        switch (o.type) {
            case 0:
                return o.var % 3 == 0 ? Atlas.JOSHUA : Atlas.SAGUARO;
            case 1:
                return Atlas.PALM;
            case 2:
                return Atlas.PINE;
            case 3:
                return o.var % 2 == 0 ? Atlas.ROCK : Atlas.BUSH;
            case 4:
                return Atlas.BOARD[o.var % 3];
            case 5:
                return Atlas.BUILD[selTrack][o.var % 3];
            case 6:
                return Atlas.LAMP[tr.night ? 1 : 0];
            default:
                return o.var % 3 == 0 ? Atlas.BUSH : Atlas.OAK;
        }
    }

    void buildTrack() {
        Random r = new Random(tr.seed);
        bl = new ArrayList<Seg>();
        bY = 0;
        addRoad(0, 30, 0, 0f, 0f);
        while (bl.size() < tr.len - 260) {
            int k = r.nextInt(8);
            int e = 18 + r.nextInt(25), h = 20 + r.nextInt(60), l = 18 + r.nextInt(25);
            float cur = (1.5f + r.nextFloat() * 3.5f) * tr.curve * (r.nextBoolean() ? 1 : -1);
            float dir = bY > 0 ? (r.nextFloat() < 0.65f ? -1 : 1) : (r.nextFloat() < 0.65f ? 1 : -1);
            float hy = tr.hill * (8 + r.nextInt(30)) * dir;
            switch (k) {
                case 0:
                    addRoad(10, 20 + r.nextInt(30), 10, 0f, 0f);
                    break;
                case 1:
                case 2:
                case 3:
                    addRoad(e, h, l, cur, 0f);
                    break;
                case 4:
                    addRoad(e, h, l, 0f, hy);
                    break;
                case 5:
                    addRoad(e, h, l, cur, hy);
                    break;
                case 6:
                    addRoad(e, h, l, cur, 0f);
                    addRoad(e, h, l, -cur, 0f);
                    break;
                default:
                    addRoad(25, 25, 25, 0f, hy * 0.5f);
                    addRoad(25, 25, 25, 0f, -hy * 0.4f);
                    break;
            }
        }
        addRoad(25, 25, 25, 0f, -bY / SEG);
        addRoad(0, 20, 0, 0f, 0f);
        bl.get(bl.size() - 1).y2 = 0f;

        segs = bl.toArray(new Seg[0]);
        N = segs.length;
        L = N * (float) SEG;
        for (Seg s : segs) s.special = s.index == LINE_IDX ? 1 : (s.index == LINE_IDX + 1 ? 2 : 0);

        // décor (sprites pixel art)
        for (int n = 6; n < N; n += 2 + r.nextInt(4)) {
            int sides = r.nextInt(3);
            for (int sd = 0; sd < 2; sd++) {
                if (sides != 2 && sides != sd) continue;
                Spr o = new Spr();
                o.type = tr.objs[r.nextInt(tr.objs.length)];
                o.var = r.nextInt(30);
                int[] sp = sprOf(o);
                o.ww = sp[2] * UNIT[o.type];
                float side = sd == 0 ? -1f : 1f;
                float far = r.nextInt(100) < 18 ? 2.5f + r.nextFloat() * 3f : r.nextFloat() * 0.8f;
                o.off = side * (1.2f + o.ww / ROAD * 0.5f + far);
                Seg s = segs[n];
                if (s.spr == null) s.spr = new ArrayList<Spr>(2);
                s.spr.add(o);
            }
        }
        // bonus : cœur / nitro / argent, sur les voies
        float[] ln = {-0.66f, 0f, 0.66f};
        for (int n = 40; n < N - 10; n += 40 + r.nextInt(40)) {
            Pick k = new Pick();
            int t = r.nextInt(100);
            k.type = t < 50 ? 2 : (t < 75 ? 1 : 0);
            k.off = ln[r.nextInt(3)];
            Seg s = segs[n];
            if (s.pk == null) s.pk = new ArrayList<Pick>(1);
            s.pk.add(k);
        }
    }

    Seg seg(float z) {
        return segs[((int) (z / SEG)) % N];
    }

    // ------------------------------------------------------------ démarrage de course
    void startRace() {
        if (!unlocked(selTrack)) return;
        tr = Tr.ALL[selTrack];
        // bonus temporaires : payés au départ
        int fe = fee(selTrack);
        if (cash < fe) return;
        cash -= fe;
        int tc = tmpTotal();
        if (tc > cash) {
            for (int i = 0; i < 4; i++) tmp[i] = false;
            tc = 0;
        }
        cash -= tc;
        tmpPaid = tc;
        for (int i = 0; i < 4; i++) tmpOn[i] = tmp[i];
        bossT = 0;
        while (betIdx > 0 && BETS[betIdx] > cash) betIdx--;
        bet = BETS[betIdx];
        buildTrack();
        int tireEff = tire + (tmp[1] ? 2 : 0);
        maxSpeed = BASE_MAX * (1f + 0.05f * eng) * CARS[selCar] * (tmp[3] ? 1.06f : 1f) * (selPilot == 0 ? 1.03f : 1f);
        steer = (1f + 0.08f * tireEff) * (selPilot == 1 ? 1.1f : 1f);
        cent = 0.3f * (1f - 0.07f * tireEff);
        offLim = maxSpeed * (0.25f + 0.03f * tireEff);
        brakeF = 1f + 0.2f * upBrk;
        nitroDur = 2.2f + 0.35f * upNit;
        nitroPow = 1f + 0.12f * upNit;
        dmgMul = (tmp[2] ? 0.4f : 1f) * (selPilot == 2 ? 0.75f : 1f);
        nitros = 3 + (tmp[0] ? 2 : 0) + (selPilot == 3 ? 1 : 0);
        for (int i = 0; i < 4; i++) tmp[i] = false;
        lineOff = LINE_IDX * SEG - PZ;
        finishDist = lineOff + tr.laps * L;
        pos = 0;
        totalDist = 0;
        speed = 0;
        playerX = 0;
        nitroT = 0;
        raceT = 0;
        finished = false;
        shake = 0;
        lean = 0;
        hint = 8f;
        cd = 3.4f;
        goT = 0;
        finT = 0;
        lapNow = 1;
        damage = 0;
        shield = 0;
        msgT = 0;
        flash = 0;
        police = null;
        policeT = 18f;
        picks = 0;
        fines = 0;
        paused = false;
        left = false;
        right = false;
        brake = false;
        nitroReq = false;
        spawnCars();
        saveAll();
        state = CD;
    }

    void spawnCars() {
        cars.clear();
        rivals.clear();
        Random r = new Random();
        ArrayList<String> pool = new ArrayList<String>();
        for (String n : NAMES) if (!n.equals(tr.boss)) pool.add(n);
        Collections.shuffle(pool, r);
        int t0 = selTrack;
        int[] chs = {4 + t0, 4 + ((t0 + 3) % 8), 4 + ((t0 + 5) % 8), (selPilot + 1 + t0 % 3) % 4};
        float[] offs = {-0.55f, 0.55f, -0.55f, 0.55f};
        float[] ds = {450f, 450f, 900f, 900f};
        int[] sidx = {0, 1, 2, 3};
        for (int k = 0; k < 4; k++) {
            Car c = new Car();
            c.type = 2;
            c.off = offs[k];
            c.dist = ds[k];
            c.z = (c.dist + PZ) % L;
            c.idx = sidx[k] == selCar ? 4 + k % 2 : sidx[k];
            c.skill = 0.97f + r.nextFloat() * 0.05f;
            c.ch = chs[k];
            c.name = CHN[c.ch];
            rivals.add(c);
            cars.add(c);
            seg(c.z).cars.add(c);
        }
        float[] lanes = {-0.66f, 0f, 0.66f};
        for (int i = 0; i < tr.traffic; i++) {
            Car c = new Car();
            c.type = r.nextInt(100) < 18 ? 1 : 0;
            c.idx = r.nextInt(6);
            c.z = 5600f + r.nextFloat() * (L - 6600f);
            c.off = lanes[r.nextInt(3)] + (r.nextFloat() - 0.5f) * 0.2f;
            c.speed = BASE_MAX * (0.16f + r.nextFloat() * 0.26f) * (c.type == 1 ? 0.8f : 1f);
            cars.add(c);
            seg(c.z).cars.add(c);
        }
    }

    // ------------------------------------------------------------ mise à jour
    void update(float dt) {
        tick++;
        if (paused) return;
        switch (state) {
            case MENU:
            case PREP:
            case GARAGE:
                bg1 += dt * 7f;
                bg2 += dt * 14f;
                clampBet();
                break;
            case CD:
                cd -= dt;
                updateCars(dt, true);
                if (cd <= 0.4f) {
                    state = RACE;
                    goT = 0.9f;
                }
                break;
            case RACE:
                updateRace(dt);
                break;
            default:
                resT += dt;
                break;
        }
    }

    static boolean ov(float x1, float w1, float x2, float w2, float pct) {
        float half = pct / 2f;
        float min1 = x1 - w1 * half, max1 = x1 + w1 * half;
        float min2 = x2 - w2 * half, max2 = x2 + w2 * half;
        return !(max1 < min2 || min1 > max2);
    }

    void hurt(float d) {
        damage = Math.min(100f, damage + d * dmgMul);
    }

    void updateRace(float dt) {
        Seg ps = seg(pos + PZ);
        float eff = maxSpeed * (1f - 0.25f * damage / 100f);
        float curMax = eff * (nitroT > 0 ? 1.25f + 0.02f * upNit : 1f);
        float pct = speed / maxSpeed;
        float dxs = dt * 2f * pct;
        float adv = dt * speed;
        pos += adv;
        totalDist += adv;
        if (pos >= L) pos -= L;

        float tl = (right ? 1f : 0f) - (left ? 1f : 0f);
        lean += (tl - lean) * Math.min(1f, dt * 8f);

        if (!finished) {
            raceT += dt;
            if (tl < 0) playerX -= dxs * steer;
            else if (tl > 0) playerX += dxs * steer;
            playerX -= dxs * pct * ps.curve * cent;
            if (nitroReq) {
                if (nitros > 0 && nitroT <= 0) {
                    nitros--;
                    nitroT = nitroDur;
                }
                nitroReq = false;
            }
            float acc = nitroT > 0 ? maxSpeed / 1.5f * nitroPow : maxSpeed / 4f;
            if (brake) speed -= maxSpeed * brakeF * dt;
            else speed += acc * dt;
        } else {
            speed -= maxSpeed * 0.4f * dt;
            finT += dt;
            if (finT > 2.2f) {
                state = RESULT;
                resT = 0;
            }
        }
        if (nitroT > 0) nitroT -= dt;
        if (speed > curMax) speed = Math.max(curMax, speed - maxSpeed * 0.3f * dt);
        if ((playerX < -1f || playerX > 1f) && speed > offLim) speed -= maxSpeed * 0.5f * dt;

        Seg q = seg(pos + PZ);
        if ((playerX < -1f || playerX > 1f) && q.spr != null) {
            for (int i = 0; i < q.spr.size(); i++) {
                Spr o = q.spr.get(i);
                if (shield <= 0f && ov(playerX, CARW, o.off, o.ww / ROAD, 1f)) {
                    if (speed > maxSpeed * 0.2f) {
                        shake = 0.4f;
                        hurt(6f);
                    }
                    speed = Math.min(speed, maxSpeed * 0.12f);
                }
            }
        }
        for (int i = 0; i < q.cars.size(); i++) {
            Car k = q.cars.get(i);
            if (k.type != 3 && shield <= 0f && speed > k.speed && ov(playerX, CARW, k.off, CARW, 0.8f)) {
                speed = k.speed * (k.speed / Math.max(1f, speed));
                float np = k.z - PZ;
                if (np < 0) np += L;
                float d = np - pos;
                if (d > L / 2) d -= L;
                else if (d < -L / 2) d += L;
                pos = np;
                totalDist += d;
                shake = 0.35f;
                hurt(10f);
                break;
            }
        }
        if (playerX < -3f) playerX = -3f;
        else if (playerX > 3f) playerX = 3f;
        if (speed < 0) speed = 0;

        updateCars(dt, false);
        updateExtras(dt);
        float bdist = Math.abs(rivals.get(0).dist - totalDist);
        if (bdist < 5000f && !finished) bossT = Math.min(1f, bossT + dt * 2f);
        else bossT = Math.max(0f, bossT - dt * 2f);

        bg1 += ps.curve * pct * dt * 30f;
        bg2 += ps.curve * pct * dt * 60f;
        if (shake > 0) shake -= dt;
        if (hint > 0) hint -= dt;
        if (goT > 0) goT -= dt;
        float ld = (totalDist - lineOff) / L;
        lapNow = ld < 0 ? 1 : Math.min(tr.laps, (int) ld + 1);

        if (!finished && totalDist >= finishDist) {
            finished = true;
            finT = 0;
            finishRace();
        }
    }

    void moveCar(Car k, Seg old, float nz) {
        Seg nw = seg(nz);
        k.z = nz;
        if (old != nw) {
            old.cars.remove(k);
            nw.cars.add(k);
        }
    }

    float steerOff(Car k, Seg cs, Seg ps) {
        int di = (cs.index - ps.index + N) % N;
        if (di > DRAW) return 0f;
        for (int i = 1; i < 20; i++) {
            Seg s = segs[(cs.index + i) % N];
            if (s == ps && k.speed > speed && ov(playerX, CARW, k.off, CARW, 1.2f)) {
                float dir = playerX > 0.5f ? -1f : (playerX < -0.5f ? 1f : (k.off > playerX ? 1f : -1f));
                return dir / i * (k.speed - speed) / BASE_MAX;
            }
            for (int j = 0; j < s.cars.size(); j++) {
                Car o = s.cars.get(j);
                if (o != k && k.speed > o.speed && ov(k.off, CARW, o.off, CARW, 1.2f)) {
                    float dir = o.off > 0.5f ? -1f : (o.off < -0.5f ? 1f : (k.off > o.off ? 1f : -1f));
                    return dir / i * (k.speed - o.speed) / BASE_MAX;
                }
            }
        }
        if (k.off < -0.8f) return 0.1f;
        if (k.off > 0.8f) return -0.1f;
        return 0f;
    }

    void updateCars(float dt, boolean frozen) {
        Seg ps = seg(pos + PZ);
        for (int i = 0; i < cars.size(); i++) {
            Car k = cars.get(i);
            Seg cs = seg(k.z);
            if (k.type == 2) {
                if (frozen) {
                    k.speed = 0;
                    continue;
                }
                float gap = totalDist - k.dist;
                float boost = Math.max(-0.06f, Math.min(0.12f, gap / 9000f));
                float target = BASE_MAX * tr.rp * k.skill * (1f + boost);
                k.speed += (target - k.speed) * Math.min(1f, dt * 1.5f);
                k.off += steerOff(k, cs, ps) * dt * 60f;
                if (k.off < -0.9f) k.off = -0.9f;
                else if (k.off > 0.9f) k.off = 0.9f;
                k.dist += dt * k.speed;
                if (!k.fin && k.dist >= finishDist) {
                    k.fin = true;
                    k.finT = raceT;
                }
                moveCar(k, cs, (k.dist + PZ) % L);
            } else if (k.type == 3) {
                if (frozen) continue;
                float gap = policeGap();
                float target = BASE_MAX * 0.92f * (gap > 2500f ? 1.1f : 1f);
                if (gap < -200f) target = BASE_MAX * 0.5f;
                k.speed += (target - k.speed) * Math.min(1f, dt * 1.2f);
                k.off += (Math.max(-0.7f, Math.min(0.7f, playerX)) - k.off) * Math.min(1f, dt * 0.8f);
                float pz2 = k.z + dt * k.speed;
                if (pz2 >= L) pz2 -= L;
                moveCar(k, cs, pz2);
            } else {
                if (frozen) continue;
                float nz = k.z + dt * k.speed;
                if (nz >= L) nz -= L;
                moveCar(k, cs, nz);
            }
        }
    }

    int curPlace() {
        int pl = 1;
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            if (k.fin || k.dist > totalDist) pl++;
        }
        return pl;
    }

    // ------------------------------------------------------------ bonus et police
    float policeGap() {
        if (police == null) return 1e9f;
        float gp = (pos + PZ) % L - police.z;
        if (gp > L / 2) gp -= L;
        else if (gp < -L / 2) gp += L;
        return gp;
    }

    void collect(Pick k) {
        flash = 0.2f;
        msgT = 1.6f;
        picks++;
        if (k.type == 0) {
            damage = Math.max(0f, damage - 35f);
            shield = 4f;
            msg = "COEUR : REPARATION + BOUCLIER";
            msgCol = 0xFFFF5A6E;
        } else if (k.type == 1) {
            if (nitros < 5) nitros++;
            nitroT = Math.max(nitroT, 1.2f);
            msg = "NITRO !";
            msgCol = 0xFF38B6FF;
        } else {
            int v = (int) ((20 + rnd.nextInt(61)) * (1f + selTrack * 0.25f));
            cash += v;
            msg = "+" + money(v);
            msgCol = 0xFFFFD400;
        }
    }

    void spawnPolice() {
        Car k = new Car();
        k.type = 3;
        k.name = "POLICE";
        float nz = (pos + PZ) % L - 4500f;
        if (nz < 0) nz += L;
        k.z = nz;
        k.off = Math.max(-0.7f, Math.min(0.7f, playerX));
        k.speed = speed * 0.9f;
        police = k;
        cars.add(k);
        seg(nz).cars.add(k);
        msg = "POLICE DERRIERE TOI !";
        msgCol = 0xFFFF6B6B;
        msgT = 1.8f;
    }

    void removePolice() {
        if (police == null) return;
        seg(police.z).cars.remove(police);
        cars.remove(police);
        police = null;
    }

    void updateExtras(float dt) {
        if (shield > 0) shield -= dt;
        if (msgT > 0) msgT -= dt;
        if (flash > 0) flash -= dt;
        if (finished) return;
        Seg q = seg(pos + PZ);
        for (int d = 0; d < 3; d++) {
            Seg s2 = segs[(q.index - d + N) % N];
            if (s2.pk == null) continue;
            for (int i = 0; i < s2.pk.size(); i++) {
                Pick k = s2.pk.get(i);
                if (!k.taken && ov(playerX, CARW, k.off, 0.25f, 1.1f)) {
                    k.taken = true;
                    collect(k);
                }
            }
        }
        if (!POLICE[selTrack]) return;
        if (police == null) {
            policeT -= dt;
            if (policeT <= 0f && raceT > 8f) spawnPolice();
            return;
        }
        float gap = policeGap();
        if (gap > 13000f) {
            removePolice();
            policeT = 25f;
            cash += 200;
            msg = "POLICE SEMEE ! +$200";
            msgCol = GREEN;
            msgT = 1.8f;
        } else if (gap < 260f && shield <= 0f && Math.abs(police.off - playerX) < 0.35f) {
            int fine = Math.min(cash, 300);
            cash -= fine;
            fines += fine;
            speed *= 0.35f;
            hurt(8f);
            shake = 0.5f;
            flash = 0.2f;
            float nz = police.z - 7000f;
            if (nz < 0) nz += L;
            moveCar(police, seg(police.z), nz);
            police.speed = speed;
            msg = "AMENDE -" + money(fine);
            msgCol = RED;
            msgT = 1.8f;
        }
    }

    void finishRace() {
        ArrayList<Car> fin = new ArrayList<Car>(), rest = new ArrayList<Car>();
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            if (k.fin) fin.add(k);
            else rest.add(k);
        }
        Collections.sort(fin, new Comparator<Car>() {
            @Override
            public int compare(Car a, Car b) {
                return Float.compare(a.finT, b.finT);
            }
        });
        Collections.sort(rest, new Comparator<Car>() {
            @Override
            public int compare(Car a, Car b) {
                return Float.compare(b.dist, a.dist);
            }
        });
        order = new ArrayList<Car>();
        order.addAll(fin);
        order.add(null);
        order.addAll(rest);
        place = fin.size() + 1;
        int bossPlace = order.indexOf(rivals.get(0)) + 1;
        prize = (int) (PRIZE[Math.min(4, place - 1)] * (1f + selTrack * 0.4f));
        int lvBefore = level();
        xpGain = (int) (XPP[Math.min(4, place - 1)] * (1f + selTrack * 0.25f)) + picks * 5;
        xp += xpGain;
        levelUp = level() > lvBefore;
        if (place <= 3) pod[selTrack] = true;
        betWon = false;
        profit = 0;
        if (bet > 0) {
            if (betMode == 0) betWon = place < bossPlace;
            else if (betMode == 1) betWon = place <= 3;
            else betWon = place == 1;
            if (betWon) profit = (int) (bet * MODE_PROFIT[betMode]);
        }
        cash += prize + profit - (bet > 0 && !betWon ? bet : 0);
        loan = false;
        if (cash < 100) {
            cash = 300;
            loan = true;
        }
        newRecord = best[selTrack] <= 0f || raceT < best[selTrack];
        if (newRecord) best[selTrack] = raceT;
        saveAll();
    }

    // ============================================================ DESSIN
    static String money(int v) {
        String s = Integer.toString(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append(' ');
            b.append(s.charAt(i));
        }
        return (v < 0 ? "-$" : "$") + b;
    }

    static String fmt(float t) {
        int m = (int) (t / 60);
        float s = t - m * 60;
        return String.format(Locale.US, "%d:%04.1f", m, s);
    }

    float frac(float d) {
        return Math.max(0f, Math.min(1f, d / finishDist));
    }

    void renderFrame() {
        Canvas c = g.c;
        switch (state) {
            case MENU:
                drawMenu();
                break;
            case PREP:
                drawBet();
                break;
            case TITLE:
                drawTitle();
                break;
            case CHAR:
                drawChar();
                break;
            case GARAGE:
                drawGarage();
                break;
            default:
                c.save();
                if (shake > 0) c.translate(Math.round((rnd.nextFloat() - 0.5f) * 4f), Math.round((rnd.nextFloat() - 0.5f) * 3f));
                drawWorld();
                c.restore();
                drawHud();
                if (state == CD) {
                    int n = (int) Math.ceil(cd - 0.4f);
                    g.text(String.valueOf(Math.max(1, n)), W / 2, H / 2 - 20, 8, WHITE, Gfx.C);
                }
                if (state == RESULT) drawResult();
                if (paused) {
                    g.dim(1, 0, 0, W, H);
                    g.text("PAUSE", W / 2, H / 2 - 16, 4, 0xFFFFD400, Gfx.C);
                    g.text("Touche l'ecran pour reprendre", W / 2, H / 2 + 14, 1, WHITE, Gfx.C);
                    g.text("Retour = abandonner", W / 2, H / 2 + 26, 1, 0xFFBBBBBB, Gfx.C);
                }
                break;
        }
    }

    // ------------------------------------------------------------ fond (ciel, nuages, montagnes, villes)
    void drawBgAt(int hy) {
        Bitmap b = g.bgSheet(selTrack);
        int ox = (512 - W) / 2;
        g.rect(0, 0, W, H, tr.skyT);
        g.blit(b, ox, 0, W, 96, 0, hy - 96, W, 96);
        g.band(b, 96, 40, bg1 * 0.35f + tick * 0.02f, hy - 84);
        g.band(b, 136, 64, bg1, hy - 62);
        g.band(b, 200, 64, bg2, hy - 62);
        g.band(b, 264, 28, bg2 * 1.4f, hy - 26);
        g.rect(0, hy + 2, W, H - hy - 2, tr.g1);
    }

    void drawHaze(int y) {
        Bitmap b = g.bgSheet(selTrack);
        int ox = (512 - W) / 2;
        g.blit(b, ox, 292, W, 24, 0, y, W, 24);
    }

    void poly(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int col) {
        g.path.reset();
        g.path.moveTo(x1, y1);
        g.path.lineTo(x2, y2);
        g.path.lineTo(x3, y3);
        g.path.lineTo(x4, y4);
        g.path.close();
        g.p.setColor(col);
        g.c.drawPath(g.path, g.p);
    }

    void drawSeg(Seg s) {
        int ci = s.color;
        g.rect(0, s.sy2, W, s.sy1 - s.sy2, ci == 0 ? tr.g1 : tr.g2);
        float r1 = s.sw1 / 6f, r2 = s.sw2 / 6f;
        int rm = ci == 0 ? tr.rm1 : tr.rm2;
        poly(s.sx1 - s.sw1 - r1, s.sy1, s.sx1 - s.sw1, s.sy1, s.sx2 - s.sw2, s.sy2, s.sx2 - s.sw2 - r2, s.sy2, rm);
        poly(s.sx1 + s.sw1 + r1, s.sy1, s.sx1 + s.sw1, s.sy1, s.sx2 + s.sw2, s.sy2, s.sx2 + s.sw2 + r2, s.sy2, rm);
        int rd = s.special == 1 ? 0xFFF2EBD3 : (s.special == 2 ? 0xFF14141A : (ci == 0 ? tr.rd1 : tr.rd2));
        poly(s.sx1 - s.sw1, s.sy1, s.sx1 + s.sw1, s.sy1, s.sx2 + s.sw2, s.sy2, s.sx2 - s.sw2, s.sy2, rd);
        if (ci == 0 && s.special == 0) {
            float lw1 = s.sw1 * 2f / 3f, lw2 = s.sw2 * 2f / 3f;
            float lx1 = s.sx1 - s.sw1 + lw1, lx2 = s.sx2 - s.sw2 + lw2;
            float m1 = Math.max(0.6f, s.sw1 / 32f), m2 = Math.max(0.6f, s.sw2 / 32f);
            for (int i = 1; i < 3; i++) {
                poly(lx1 - m1 / 2, s.sy1, lx1 + m1 / 2, s.sy1, lx2 + m2 / 2, s.sy2, lx2 - m2 / 2, s.sy2, 0xFFF2EBD3);
                lx1 += lw1;
                lx2 += lw2;
            }
        }
    }

    void drawPick(int type, float cx, float by, float w) {
        int[] r;
        if (type == 0) r = Atlas.PICK_HEART[(tick / 12) & 1];
        else if (type == 1) r = Atlas.PICK_BOLT;
        else r = Atlas.PICK_COIN[(tick / 6) & 3];
        g.spriteB(r, cx, by, w);
    }

    void drawWorld() {
        Seg base = seg(pos);
        float bp = (pos % SEG) / SEG;
        Seg ps = seg(pos + PZ);
        float pp = ((pos + PZ) % SEG) / SEG;
        float py = ps.y1 + (ps.y2 - ps.y1) * pp;
        float camY = py + CAMH, camX = playerX * ROAD;

        drawBgAt(H / 2 + 2);

        float maxy = H, x = 0, dx = -(base.curve * bp);
        float hw = W * 0.5f, hh = H * 0.5f;
        for (int n = 0; n < DRAW; n++) {
            Seg s = segs[(base.index + n) % N];
            boolean looped = s.index < base.index;
            float cz = pos - (looped ? L : 0f);
            float z1 = s.z1 - cz, z2 = s.z2 - cz;
            s.clip = maxy;
            float cx1 = x - camX, cx2 = x + dx - camX;
            x += dx;
            dx += s.curve;
            if (z1 <= CAMD) {
                s.valid = false;
                continue;
            }
            s.valid = true;
            float sc1 = CAMD / z1, sc2 = CAMD / z2;
            s.sc1 = sc1;
            s.sc2 = sc2;
            s.sx1 = hw + sc1 * cx1 * hw;
            s.sy1 = hh - sc1 * (s.y1 - camY) * hh;
            s.sw1 = sc1 * ROAD * hw;
            s.sx2 = hw + sc2 * cx2 * hw;
            s.sy2 = hh - sc2 * (s.y2 - camY) * hh;
            s.sw2 = sc2 * ROAD * hw;
            if (s.sy2 >= s.sy1 || s.sy2 >= maxy) continue;
            drawSeg(s);
            maxy = s.sy1;
        }
        horizon = maxy;

        Canvas c = g.c;
        for (int n = DRAW - 1; n > 0; n--) {
            Seg s = segs[(base.index + n) % N];
            if (!s.valid) continue;
            if (s.spr != null) {
                for (int i = 0; i < s.spr.size(); i++) {
                    Spr o = s.spr.get(i);
                    int[] sp = sprOf(o);
                    float u = UNIT[o.type];
                    float w = sp[2] * u * s.sc1 * hw, h = sp[3] * u * s.sc1 * hw;
                    float sx = s.sx1 + s.sc1 * o.off * ROAD * hw, sy = s.sy1;
                    if (w < 2f || sx + w * 2f < 0 || sx - w * 2f > W) continue;
                    if (sy - h >= s.clip) continue;
                    boolean clip = sy > s.clip;
                    if (clip) {
                        c.save();
                        c.clipRect(0, 0, W, s.clip);
                    }
                    if (o.type == 6 && o.off < 0) g.spriteBFlip(sp, sx, sy, w);
                    else g.spriteB(sp, sx, sy, w);
                    if (clip) c.restore();
                }
            }
            if (s.pk != null) {
                for (int i = 0; i < s.pk.size(); i++) {
                    Pick pk = s.pk.get(i);
                    if (pk.taken) continue;
                    float pw2 = s.sc1 * 24f * 20f * hw;
                    float px = s.sx1 + s.sc1 * pk.off * ROAD * hw;
                    float py2 = s.sy1 - pw2 * (0.2f + 0.08f * (float) Math.sin(tick * 0.12f + s.index));
                    if (pw2 < 3f || px + pw2 < 0 || px - pw2 > W || py2 > s.clip) continue;
                    drawPick(pk.type, px, py2, pw2);
                }
            }
            for (int i = 0; i < s.cars.size(); i++) {
                Car k = s.cars.get(i);
                float kp = (k.z % SEG) / SEG;
                float sc = s.sc1 + (s.sc2 - s.sc1) * kp;
                float cx = s.sx1 + (s.sx2 - s.sx1) * kp + sc * k.off * ROAD * hw;
                float cy = s.sy1 + (s.sy2 - s.sy1) * kp;
                float cw = sc * CARW * ROAD * hw;
                if (cw < 2f || cx + cw < 0 || cx - cw > W) continue;
                int[] sp = carSprite(k);
                float ch = cw * sp[3] / sp[2];
                if (cy - ch >= s.clip) continue;
                boolean clip = cy > s.clip;
                if (clip) {
                    c.save();
                    c.clipRect(0, 0, W, s.clip);
                }
                g.spriteB(sp, cx, cy, cw);
                if (k == rivals.get(0) && cw > 10f) tag(cx, cy - ch - 1);
                if (clip) c.restore();
            }
        }

        // brume d'horizon (tramée)
        drawHaze((int) horizon - 20);

        // voiture du joueur
        int li = lean < -0.4f ? -1 : (lean > 0.4f ? 1 : 0);
        int[] psp = Atlas.PL[selCar * 6 + (li + 1) * 2 + (brake ? 1 : 0)];
        float pw = 84f;
        float pcx = W / 2f + li * 2;
        float pby = H - 3 + (speed > 800f && ((tick / 3) & 1) == 0 ? 1 : 0);
        g.spriteB(psp, pcx, pby, pw);
        if ((playerX < -1f || playerX > 1f) && speed > 1500f) {
            for (int i = 0; i < 6; i++) g.rect(pcx - 34 + rnd.nextInt(68), pby - 2 - rnd.nextInt(6), 3, 2, 0xAA9A7A50);
        }
        if (nitroT > 0) {
            float[] fx = {pcx - 12f, pcx + 11f};
            for (int i = 0; i < 2; i++) {
                int fl = 6 + rnd.nextInt(6);
                g.rect(fx[i] - 3, pby - 8, 6, fl, 0xFFFF7A1A);
                g.rect(fx[i] - 2, pby - 8, 4, fl - 2, 0xFFFFC83A);
                g.rect(fx[i] - 1, pby - 8, 2, fl - 4, 0xFFFFF6B0);
            }
        }
        if (damage > 50f) {
            for (int i = 0; i < 3; i++) {
                int sy = (int) pby - 46 - ((tick * 2 + i * 9) % 20);
                g.rect(pcx - 22 + i * 22, sy, 4, 4, 0x88606068);
            }
        }
        if (shield > 0f && (shield > 1f || ((tick / 4) & 1) == 0)) {
            g.p.setStyle(Paint.Style.STROKE);
            g.p.setStrokeWidth(1f);
            g.p.setColor(0xFF7FD4FF);
            c.drawOval(pcx - 52, pby - 52, pcx + 52, pby + 2, g.p);
            g.p.setColor(0xAA38B6FF);
            c.drawOval(pcx - 50, pby - 50, pcx + 50, pby, g.p);
            g.p.setStyle(Paint.Style.FILL);
        }
        if (nitroT > 0) {
            g.p.setColor(0x66FFFFFF);
            for (int i = 0; i < 8; i++) {
                int ly = 30 + rnd.nextInt(H - 60);
                boolean lft = (i & 1) == 0;
                c.drawRect(lft ? 0 : W - 24 - rnd.nextInt(12), ly, lft ? 12 + rnd.nextInt(20) : W, ly + 1, g.p);
            }
        }
    }

    int[] carSprite(Car k) {
        if (k.type == 2) return Atlas.SPORT[k.idx % 6];
        if (k.type == 1) return Atlas.TRUCK[k.idx % 2];
        if (k.type == 3) return Atlas.POLICE[((tick / 5) & 1)];
        return Atlas.SEDAN[k.idx % 6];
    }

    // ------------------------------------------------------------ interface commune
    void btn(int[] r, String label, int style) {
        g.nine(Atlas.BTN[style], r[0], r[1], r[2], r[3]);
        int col = style == 1 ? 0xFF2A1400 : (style == 2 ? 0xFF8A7A70 : WHITE);
        g.text(label, r[0] + r[2] / 2, r[1] + (r[3] - 7) / 2, 1, col, Gfx.C, style != 1);
    }

    void stars(int x, int y, int n) {
        for (int i = 0; i < 5; i++) g.sprite1(i < n ? Atlas.ICON_STAR : Atlas.ICON_STAR0, x + i * 12, y, 1);
    }

    void seg5(int x, int y, int n, int on, int col, int sw, int sh) {
        for (int i = 0; i < n; i++) g.rect(x + i * (sw + 1), y, sw, sh, i < on ? col : 0xFF3A2A20);
    }

    // ------------------------------------------------------------ HUD de course
    void drawHud() {
        int y = 2, h = 28, gap = 3;
        int wl = 30, wb = 80, wm = 92, wt = 64, wp = 34;
        int x = 2;
        // niveau
        g.panel(x, y, wl, h);
        g.text("NIV", x + wl / 2, y + 4, 1, GOLD, Gfx.C, false);
        g.text(String.valueOf(level()), x + wl / 2, y + 12, 2, WHITE, Gfx.C);
        x += wl + gap;
        // boost / damage
        g.panel(x, y, wb, h);
        g.text("BOOST", x + 5, y + 5, 1, GOLD, Gfx.L, false);
        seg5(x + 43, y + 5, 5, nitros, nitroT > 0 ? 0xFFFF9A20 : 0xFF38B6FF, 5, 7);
        g.text("DAMAGE", x + 5, y + 17, 1, GOLD, Gfx.L, false);
        int hp = Math.round((1f - damage / 100f) * 6f);
        seg5(x + 43, y + 17, 6, hp, hp > 3 ? GREEN : (hp > 1 ? ORANGE : 0xFFFF4040), 4, 7);
        x += wb + gap;
        // argent / distance
        g.panel(x, y, wm, h);
        g.text("ARGENT", x + 5, y + 5, 1, GOLD, Gfx.L, false);
        g.text(money(cash), x + wm - 5, y + 5, 1, WHITE, Gfx.RT, false);
        g.text("DIST", x + 5, y + 17, 1, GOLD, Gfx.L, false);
        int bx = x + 30, bw = wm - 36;
        g.rect(bx, y + 18, bw, 6, 0xFF3A2A20);
        g.rect(bx, y + 18, Math.round(bw * frac(totalDist)), 6, 0xFFC8843A);
        for (int i = 0; i < rivals.size(); i++) {
            Car k = rivals.get(i);
            g.rect(bx + Math.round(bw * frac(k.dist)) - 1, y + 19, 3, 4, RCOL(k.idx));
        }
        g.rect(bx + Math.round(bw * frac(totalDist)) - 1, y + 17, 3, 8, 0xFFFFD400);
        x += wm + gap;
        // tour / temps
        g.panel(x, y, wt, h);
        g.text("TOUR " + lapNow + "/" + tr.laps, x + 5, y + 5, 1, WHITE, Gfx.L, false);
        g.text(fmt(raceT), x + 5, y + 17, 1, ORANGE, Gfx.L, false);
        x += wt + gap;
        // position (collée à droite)
        int px = W - 2 - wp;
        g.panel(px, y, wp, h);
        g.text("POS", px + wp / 2, y + 4, 1, GOLD, Gfx.C, false);
        g.text(String.valueOf(curPlace()), px + wp / 2, y + 12, 2, 0xFFFFD400, Gfx.C);
        int free = px - x - gap;
        if (free >= 46) {
            g.panel(x, y, free, h);
            int[][] ic2 = {Atlas.ICON_FLAME, Atlas.ICON_TIRE, Atlas.ICON_SHIELD, Atlas.ICON_ENGINE};
            int n4 = Math.min(4, (free - 4) / 15);
            for (int i = 0; i < n4; i++) {
                g.rect(x + 4 + i * 15, y + 6, 14, 16, 0xFF140C08);
                boolean on = i == 2 ? (tmpOn[2] || shield > 0) : tmpOn[i];
                if (on) g.sprite1(ic2[i], x + 4 + i * 15, y + 8, 1);
            }
        }

        // vitesse
        g.text(String.valueOf((int) (speed * 0.02f)), 5, H - 32, 3, ORANGE, Gfx.L);
        g.text("KM/H", 6, H - 9, 1, GOLD, Gfx.L);

        if (flash > 0) g.rect(0, 0, W, H, ((int) (Math.min(1f, flash * 5f) * 70f) << 24) | 0x00FFFFFF);
        if (msgT > 0 && msg != null) {
            int a = (int) (Math.min(1f, msgT / 0.5f) * 255f);
            g.text(msg, W / 2, H / 3 - (int) ((1.6f - msgT) * 12f), 2, (a << 24) | (msgCol & 0x00FFFFFF), Gfx.C);
        }
        if (police != null && state == RACE && policeGap() < 7000f) {
            boolean ph = ((tick / 8) & 1) == 0;
            g.rect(0, 34, 4, H, ph ? 0xAAFF2020 : 0xAA2060FF);
            g.rect(W - 4, 34, 4, H, ph ? 0xAA2060FF : 0xAAFF2020);
            g.text("POLICE !", W / 2, 40, 2, ph ? 0xFFFF4040 : 0xFF5C90FF, Gfx.C);
        }
        if (bossT > 0.02f && state == RACE) {
            int qx = 2 - Math.round((1f - bossT) * 52f), qy = 34;
            g.sprite1(Atlas.PORT[4 + selTrack], qx, qy, 1);
            g.rect(qx, qy + 49, 44, 9, 0xFFB01818);
            g.text("RIVAL", qx + 22, qy + 50, 1, WHITE, Gfx.C, false);
            g.text(first(CHN[4 + selTrack]), qx + 22, qy + 60, 1, 0xFFFF8A7A, Gfx.C);
        }
        if (goT > 0) g.text("GO !", W / 2, H / 2 - 20, 6, GREEN, Gfx.C);
        if (finished && state == RACE) g.text("ARRIVEE !", W / 2, H / 2 - 16, 4, 0xFFFFD400, Gfx.C);
        if (hint > 0 && state != RESULT) {
            g.text("Gauche/droite = diriger   Haut = frein   Bas = nitro", W / 2, 36, 1, 0xCCFFFFFF, Gfx.C);
        }
    }

    static int RCOL(int idx) {
        int[] c = {0xFFE0202E, 0xFFEEEEF2, 0xFF2D6CFF, 0xFF2FBF4F, 0xFFFF7A00, 0xFF9A3AD0};
        return c[idx % 6];
    }

    // ------------------------------------------------------------ résultat : le podium
    void tag(float x, float y) {
        int w = 34, bx = Math.round(x) - w / 2, by = Math.round(y) - 11;
        g.rect(bx, by, w, 10, 0xFFB01818);
        g.rect(bx, by, w, 1, 0xFFFF6A5A);
        g.rect(bx, by + 9, w, 1, 0xFF500808);
        g.text("RIVAL", Math.round(x), by + 2, 1, WHITE, Gfx.C, false);
        g.rect(Math.round(x) - 1, by + 10, 3, 1, 0xFFB01818);
    }

    static String first(String n) {
        int i = n.indexOf(' ');
        return i < 0 ? n : n.substring(0, i);
    }

    void drawResult() {
        g.rect(0, 0, W, H, 0xFF1A0404);
        g.blit(g.podium(), 0, 0, 440, 180, Math.round((W - 440) / 2f), 0, 440, 180);
        g.text(tr.name, W / 2, 4, 1, 0xFFE8742A, Gfx.C);
        int cx = W / 2;
        int[] rx = {cx - 22, cx - 22 - 70, cx - 22 + 70};
        int[] ry = {26, 50, 50};
        float mult = 1f + selTrack * 0.4f;
        int onPod = -1;
        for (int r = 0; r < 3; r++) {
            Car k = order.get(r);
            int pi = k == null ? selPilot : k.ch;
            String nm = k == null ? "TOI" : first(CHN[k.ch]);
            g.text(money((int) (PRIZE[r] * mult)), rx[r] + 22, ry[r] - 9, 1, 0xFFFFD27A, Gfx.C);
            g.sprite1(Atlas.PORT[pi], rx[r], ry[r], 1);
            if (k == null) {
                onPod = r;
                g.p.setStyle(Paint.Style.STROKE);
                g.p.setStrokeWidth(2f);
                g.p.setColor(((tick / 10) & 1) == 0 ? 0xFFFFFFFF : 0xFFFFD400);
                g.c.drawRect(rx[r] - 1, ry[r] - 1, rx[r] + 45, ry[r] + 49, g.p);
                g.p.setStyle(Paint.Style.FILL);
            }
            g.text(nm, rx[r] + 22, ry[r] + 51, 1, k == null ? 0xFFFFD400 : WHITE, Gfx.C);
            g.text(String.valueOf(r + 1), rx[r] + 22, ry[r] + 62, 3, r == 0 ? 0xFFFFD400 : ORANGE, Gfx.C);
        }
        if (onPod < 0) {
            g.sprite1(Atlas.PORT[selPilot], 6, 40, 1);
            g.text("TU ES " + place + "E", 28, 92, 1, WHITE, Gfx.C);
        }
        int pw = W - 72;
        g.panel(2, 140, pw, 38);
        String l1 = bet > 0 ? (betWon ? "PARI +" + money(profit) : "PARI -" + money(bet)) : "SANS PARI";
        g.text(l1, 8, 145, 1, bet > 0 ? (betWon ? GREEN : RED) : 0xFFBBBBBB, Gfx.L, false);
        g.text("PRIME +" + money(prize), 8 + pw / 2, 145, 1, WHITE, Gfx.L, false);
        g.text("XP +" + xpGain + (levelUp ? "  NIVEAU " + level() + " !" : ""), 8, 155, 1, levelUp ? 0xFFFFD400 : 0xFF7FD0FF, Gfx.L, false);
        if (fines > 0) g.text("AMENDES -" + money(fines), 8 + pw / 2, 155, 1, RED, Gfx.L, false);
        g.text("SOLDE " + money(cash), 8, 165, 1, 0xFFFFD400, Gfx.L, false);
        g.text((newRecord ? "RECORD " : "TEMPS ") + fmt(raceT), 8 + pw / 2, 165, 1, newRecord ? GREEN : 0xFFDDDDDD, Gfx.L, false);
        btn(rRep, "REJOUER", 1);
        btn(rMen, "MENU", 0);
    }

    // ------------------------------------------------------------ écran 1 : la carte des USA
    void dotted(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 4f);
        for (int i = 0; i <= n; i++) {
            float t = n == 0 ? 0 : i / (float) n;
            g.rect(Math.round(x0 + dx * t), Math.round(y0 + dy * t), 2, 2, 0xCCF2EBD3);
        }
    }

    void drawTitle() {
        g.rect(0, 0, W, H, 0xFF0A0A12);
        g.blit(g.title(), 0, 0, 440, 180, Math.round((W - 440) / 2f), 0, 440, 180);
        if (((tick / 24) & 1) == 0) g.text("TOUCHE POUR JOUER", W / 2, H - 14, 1, WHITE, Gfx.C);
    }

    void drawChar() {
        g.rect(0, 0, W, H, 0xFF000000);
        g.text("CHOISIS TON PILOTE", W / 2, 8, 2, 0xFFE8742A, Gfx.C);
        for (int i = 0; i < 4; i++) {
            int[] r = rPort[i];
            g.sprite(Atlas.PORT[i], r[0], r[1], r[2], r[3]);
            if (i == viewPilot) {
                g.p.setStyle(Paint.Style.STROKE);
                g.p.setStrokeWidth(2f);
                g.p.setColor(((tick / 8) & 1) == 0 ? 0xFFFFFFFF : 0xFFFFD400);
                g.c.drawRect(r[0] - 2, r[1] - 2, r[0] + r[2] + 2, r[1] + r[3] + 2, g.p);
                g.p.setStyle(Paint.Style.FILL);
            }
        }
        int infoY = rPort[0][1] + rPort[0][3] + 6, infoH = H - infoY - 4;
        g.panel(4, infoY, W - 8, infoH);
        g.text(CHN[viewPilot], 12, infoY + 7, 2, WHITE, Gfx.L);
        g.text("BONUS : " + PERK[viewPilot], 12, infoY + 28, 1, ORANGE, Gfx.L, false);
        btn(rOk, viewPilot == selPilot && pilotSet ? "EN PISTE" : "CHOISIR", 1);
    }

    void drawMenu() {
        float ox = (W - 440) / 2f;
        g.rect(0, 0, W, H, 0xFF102846);
        g.blit(g.map, 0, 0, 440, 180, Math.round(ox), MAPDY, 440, 180);
        int n = Atlas.MAP_PTS.length;
        for (int i = 0; i < n; i++) {
            float px = Atlas.MAP_PTS[i][0] + ox, py = Atlas.MAP_PTS[i][1] + MAPDY;
            int[] lm = Atlas.LM[LMI[i]];
            g.sprite1(lm, Math.round(px) + 8, Math.round(py) - 4 - lm[3], 1);
        }
        for (int i = 0; i < n; i++) {
            float px = Atlas.MAP_PTS[i][0] + ox, py = Atlas.MAP_PTS[i][1] + MAPDY;
            boolean un = unlocked(i);
            int st = !un ? 0 : (pod[i] ? 2 : 1);
            int bob = i == selTrack && !detail ? ((tick / 10) & 1) : 0;
            g.sprite(Atlas.STAR[st], Math.round(px) - 7, Math.round(py) - 7 - bob, 15, 15);
            g.text(ST[i], Math.round(px), Math.round(py) + 9, 1, 0xFFF2EBD3, Gfx.C);
            if (i == selTrack) {
                int ax = Math.round(px), ay = Math.round(py) - 12 - ((tick / 8) & 1) * 2;
                g.p.setColor(0xFFE8282A);
                g.tri(ax - 4, ay - 6, ax + 4, ay - 6, ax, ay);
            }
        }
        // légende
        g.sprite1(Atlas.STAR[0], 4, H - 40, 1);
        g.text("BLOQUEE", 22, H - 36, 1, 0xFFF2EBD3, Gfx.L);
        g.sprite1(Atlas.STAR[1], 4, H - 26, 1);
        g.text("LIBRE", 22, H - 22, 1, 0xFFF2EBD3, Gfx.L);
        g.sprite1(Atlas.STAR[2], 4, H - 12, 1);
        g.text("PODIUM", 22, H - 8, 1, 0xFFF2EBD3, Gfx.L);
        // bandeau haut : pilote, argent, niveau, garage
        g.sprite(Atlas.PORT[selPilot], rPilot[0], rPilot[1], 44, 48);
        g.panel(50, 2, 108, 22);
        g.text("ARGENT", 56, 6, 1, GOLD, Gfx.L, false);
        g.text(money(cash), 154, 14, 1, WHITE, Gfx.RT, false);
        g.panel(50, 26, 108, 22);
        g.text("NIV " + level(), 56, 30, 1, WHITE, Gfx.L, false);
        g.rect(56, 40, 96, 4, 0xFF3A2A20);
        g.rect(56, 40, Math.round(96 * lvFrac()), 4, 0xFFE0A030);
        btn(rGarage, "GARAGE", 0);
        if (!detail) g.text("CHOISIS UNE ETOILE", W - 6, 8, 1, 0xFFF2EBD3, Gfx.RT);
        if (detail) drawDetail();
    }

    void drawDetail() {
        g.dim(1, 0, 0, W, H);
        int[] p = rDPanel;
        int px = p[0], py = p[1], pw = p[2];
        g.nine(Atlas.BTN[3], px, py, pw, p[3]);
        boolean un = unlocked(selTrack);
        int k = g.tw(tr.name.toUpperCase(Locale.FRANCE), 2) <= pw - 20 ? 2 : 1;
        g.text(tr.name, px + pw / 2, py + 8, k, 0xFFFFD27A, Gfx.C);
        g.text(tr.state + "  " + tr.laps + " TOURS", px + pw / 2, py + 26, 1, 0xFFCCCCCC, Gfx.C, false);
        int lx = px + 12, rx = px + pw / 2 + 4, y0 = py + 36;
        g.text("FRAIS  : " + money(fee(selTrack)), lx, y0, 1, WHITE, Gfx.L, false);
        g.text("PRIME  : " + money((int) (PRIZE[0] * (1f + selTrack * 0.4f))), lx, y0 + 11, 1, 0xFFFFD27A, Gfx.L, false);
        g.text("RECORD : " + (best[selTrack] > 0 ? fmt(best[selTrack]) : "--"), lx, y0 + 22, 1, 0xFFDDDDDD, Gfx.L, false);
        g.text("ADVERS.: " + DIFF[selTrack], rx, y0, 1, WHITE, Gfx.L, false);
        g.text("POLICE : " + (POLICE[selTrack] ? "OUI" : "NON"), rx, y0 + 11, 1, POLICE[selTrack] ? RED : GREEN, Gfx.L, false);
        g.text("METEO  : " + (tr.night ? "NUIT" : "JOUR"), rx, y0 + 22, 1, WHITE, Gfx.L, false);
        int[] chs = {4 + selTrack, 4 + ((selTrack + 3) % 8), 4 + ((selTrack + 5) % 8)};
        int gx = px + (pw - 3 * 44 - 2 * 14) / 2, gy = py + 70;
        for (int i = 0; i < 3; i++) {
            int x = gx + i * 58;
            g.sprite1(Atlas.PORT[chs[i]], x, gy, 1);
            g.text(first(CHN[chs[i]]), x + 22, gy + 50, 1, i == 0 ? 0xFFFF8A7A : WHITE, Gfx.C);
        }
        g.rect(gx, gy, 22, 9, 0xFFB01818);
        g.text("BOSS", gx + 11, gy + 1, 1, WHITE, Gfx.C, false);
        if (!un) {
            String cond = "VERROUILLE : ";
            if (level() < REQ[selTrack]) cond += "NIVEAU " + REQ[selTrack];
            if (selTrack > 0 && !pod[selTrack - 1]) cond += (level() < REQ[selTrack] ? " + " : "") + "PODIUM PREC.";
            g.text(cond, px + pw / 2, py + 129, 1, RED, Gfx.C, false);
        }
        btn(rDX, "FERMER", 0);
        btn(rDGo, un ? "COURSE" : "VERROUILLEE", un ? 1 : 2);
    }

    // ------------------------------------------------------------ écran 2 : les paris
    void drawBet() {
        g.rect(0, 0, W, H, 0xFF0A0404);
        g.blit(g.bet(), 0, 0, 440, 82, Math.round((W - 440) / 2f), 30, 440, 82);
        int fe = fee(selTrack);
        int stake = BETS[betIdx];
        int pw3 = (W - 8) / 3;
        String[] lab = {"MISE", "ARGENT", "GAIN"};
        int win = (int) (PRIZE[0] * (1f + selTrack * 0.4f)) + (int) (stake * MODE_PROFIT[betMode]);
        String[] val = {stake > 0 ? money(stake) : "--", money(cash - fe - tmpTotal()), money(win)};
        for (int i = 0; i < 3; i++) {
            int x = 2 + i * (pw3 + 2);
            g.panel(x, 2, pw3, 26);
            g.text(lab[i], x + pw3 / 2, 6, 1, GOLD, Gfx.C, false);
            g.text(val[i], x + pw3 / 2, 16, 1, i == 1 ? GREEN : WHITE, Gfx.C, false);
        }
        int[] chs = {4 + selTrack, 4 + ((selTrack + 3) % 8), 4 + ((selTrack + 5) % 8), selPilot};
        int sx = (W - 4 * 44 - 3 * 14) / 2;
        for (int i = 0; i < 4; i++) {
            int x = sx + i * 58;
            g.sprite1(Atlas.PORT[chs[i]], x, 34, 1);
            g.text(i == 3 ? "TOI" : first(CHN[chs[i]]), x + 22, 84, 1, i == 3 ? 0xFFFFD400 : WHITE, Gfx.C);
            boolean in = betMode > 0 || i == 0 || i == 3;
            g.text(in && stake > 0 ? money(stake) : "--", x + 22, 94, 1, in && stake > 0 ? 0xFFB8F5C0 : 0xFF8A7A70, Gfx.C, false);
        }
        if (betMode == 0) {
            g.rect(sx, 34, 22, 9, 0xFFB01818);
            g.text("DUEL", sx + 11, 35, 1, WHITE, Gfx.C, false);
        }
        // contrôles
        String[] ml = {"DUEL BOSS x2", "TOP 3  x1,5", "VICTOIRE x3,5"};
        for (int i = 0; i < 3; i++) btn(rMode[i], ml[i], betMode == i ? 1 : 0);
        g.text("FRAIS " + money(fe), 4, 163, 1, ORANGE, Gfx.L, false);
        btn(rBM, "-", betIdx > 0 ? 0 : 2);
        btn(rBox, stake == 0 ? "SANS PARI" : money(stake), 3);
        btn(rBP, "+", (betIdx < BETS.length - 1 && BETS[betIdx + 1] <= cash - tmpTotal() - fe) ? 0 : 2);
        int[][] ic = {Atlas.ICON_FLAME, Atlas.ICON_TIRE, Atlas.ICON_SHIELD, Atlas.ICON_ENGINE};
        for (int i = 0; i < 4; i++) {
            int[] r = rTmp[i];
            boolean can = tmp[i] || cash - tmpTotal() - fe >= TMPC[i];
            g.nine(Atlas.BTN[tmp[i] ? 3 : (can ? 0 : 2)], r[0], r[1], r[2], r[3]);
            g.sprite1(ic[i], r[0] + (r[2] - ic[i][2]) / 2, r[1] + 5, 1);
            g.text(money(TMPC[i]), r[0] + r[2] / 2, r[1] + 20, 1, can ? ORANGE : 0xFF8A7A70, Gfx.C, false);
            if (tmp[i]) g.sprite1(Atlas.ICON_CHECK, r[0] + r[2] - 12, r[1] + 3, 1);
        }
        g.text(capt, rTmp[0][0], 170, 1, 0xFFDDDDDD, Gfx.L, false);
        btn(rBack, "RETOUR", 0);
        boolean ok = cash >= fe + tmpTotal();
        btn(rGo, ok ? "DEMARRER !" : "FONDS INSUF.", ok ? 1 : 2);
    }

    // ------------------------------------------------------------ garage
    void drawGarage() {
        g.rect(0, 0, W, H, 0xFF1A0F0A);
        g.rect(0, H - 56, W, 56, 0xFF26160D);
        g.rect(0, H - 56, W, 1, 0xFF4A2A14);
        for (int x = 0; x < W; x += 16) g.rect(x, 0, 1, H - 56, 0xFF1F1210);
        btn(rGB, "RETOUR", 0);
        g.text("GARAGE", W / 2, 10, 2, 0xFFFFD400, Gfx.C);
        g.text(money(cash), W - 6, 10, 1, GREEN, Gfx.RT);

        // voiture (x2, pixels nets)
        g.panel(4, 28, 150, H - 34);
        int vc = viewCar;
        g.text(CARN[vc], 79, 36, 2, WHITE, Gfx.C);
        g.rect(14, 114, 130, 3, 0xFF140C08);
        g.rect(14, 117, 130, 1, 0xFFB8732E);
        g.sprite(Atlas.PL[vc * 6 + 2], 79 - 56, 112 - 60, 112, 60);
        g.text(vc == 0 ? "Voiture de depart" : "+" + Math.round((CARS[vc] - 1f) * 100f) + "% vitesse", 79, 121, 1, 0xFFDDDDDD, Gfx.C, false);
        if (level() < CARL[vc]) g.text("NIVEAU " + CARL[vc] + " REQUIS", 79, 132, 1, RED, Gfx.C, false);
        int[] a = rCprev, b = rCnext;
        g.nine(Atlas.BTN[0], a[0], a[1], a[2], a[3]);
        g.sprite1(Atlas.ICON_AL, a[0] + 7, a[1] + 5, 1);
        g.nine(Atlas.BTN[0], b[0], b[1], b[2], b[3]);
        g.sprite1(Atlas.ICON_AR, b[0] + 7, b[1] + 5, 1);
        boolean ok = level() >= CARL[vc];
        btn(rCuse, selCar == vc ? "EN SERVICE" : (ok ? "UTILISER" : "VERROUILLEE"), selCar == vc ? 1 : (ok ? 0 : 2));

        // améliorations permanentes
        int gx = 158, gw = W - gx - 4, rh = (H - 40) / 4;
        int[][] ic = {Atlas.ICON_ENGINE, Atlas.ICON_TIRE, Atlas.ICON_BRAKE, Atlas.ICON_FLAME};
        for (int i = 0; i < 4; i++) {
            int y0 = 28 + i * rh + 2;
            g.panel(gx, y0, gw, rh - 2);
            g.sprite1(ic[i], gx + 6, y0 + (rh - 2) / 2 - 6, 1);
            g.text(UPN[i], gx + 24, y0 + 5, 1, WHITE, Gfx.L, false);
            g.text(UPD[i], gx + 24, y0 + 14, 1, 0xFFBBBBBB, Gfx.L, false);
            int lv = upLv(i);
            for (int j = 0; j < 5; j++) g.rect(gx + 24 + j * 9, y0 + 23, 7, 5, j < lv ? 0xFFFFD400 : 0xFF3A2A20);
            boolean can = lv < 5 && cash >= cost(lv);
            btn(rUp[i], lv >= 5 ? "MAX" : money(cost(lv)), lv >= 5 ? 1 : (can ? 0 : 2));
        }
    }

    // ------------------------------------------------------------ audio (moteur + sirène synthétiques)
    void initAudio() {
        try {
            int period = 200, reps = 8, n = period * reps;
            short[] buf = new short[n];
            for (int i = 0; i < n; i++) {
                double ph = 2 * Math.PI * (i % period) / period;
                double v = Math.sin(ph) + 0.55 * Math.sin(2 * ph + 0.6) + 0.35 * Math.sin(3 * ph + 1.1) + 0.22 * Math.sin(5 * ph);
                double m = 1 + 0.18 * Math.sin(2 * Math.PI * i / n * 3);
                buf[i] = (short) (v * m * 5200);
            }
            at = new AudioTrack(AudioManager.STREAM_MUSIC, AT_SR, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC);
            at.write(buf, 0, n);
            at.setLoopPoints(0, n, -1);
            at.setVolume(0f);
            at.play();
        } catch (Throwable t) {
            at = null;
        }
        try {
            int n2 = AT_SR * 4 / 5;
            short[] sb = new short[n2];
            for (int i = 0; i < n2; i++) {
                double f = i < n2 / 2 ? 760.0 : 1010.0;
                sb[i] = (short) (Math.sin(2 * Math.PI * f * i / AT_SR) * 3500);
            }
            sir = new AudioTrack(AudioManager.STREAM_MUSIC, AT_SR, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, n2 * 2, AudioTrack.MODE_STATIC);
            sir.write(sb, 0, n2);
            sir.setLoopPoints(0, n2, -1);
            sir.setVolume(0f);
            sir.play();
        } catch (Throwable t) {
            sir = null;
        }
    }

    void stopAudio() {
        try {
            if (at != null) {
                at.stop();
                at.release();
            }
        } catch (Throwable t) {
            // ignore
        }
        at = null;
        try {
            if (sir != null) {
                sir.stop();
                sir.release();
            }
        } catch (Throwable t) {
            // ignore
        }
        sir = null;
    }

    void audio() {
        try {
            boolean on = (state == RACE || state == CD) && !paused;
            if (at != null) {
                float pct = maxSpeed > 0 ? Math.min(1.4f, speed / maxSpeed) : 0f;
                at.setVolume(on ? 0.12f + 0.2f * Math.min(1f, pct) : 0f);
                at.setPlaybackRate((int) (AT_SR * Math.min(2f, 0.7f + 1.2f * pct)));
            }
            if (sir != null) {
                float sv = 0f;
                if (on && police != null) sv = Math.max(0f, 0.3f * (1f - Math.abs(policeGap()) / 9000f));
                sir.setVolume(sv);
            }
        } catch (Throwable t) {
            // ignore
        }
    }
}
